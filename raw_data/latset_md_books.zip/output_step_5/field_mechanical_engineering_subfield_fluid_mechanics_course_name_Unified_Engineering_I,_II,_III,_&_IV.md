# NOTE - THIS TEXTBOOK WAS AI GENERATED

This textbook was generated using AI techniques. While it aims to be factual and accurate, please verify any critical information. The content may contain errors, biases or harmful content despite best efforts. Please report any issues.

# Comprehensive Guide to Unified Engineering":

## Foreward

Welcome to the "Comprehensive Guide to Unified Engineering". This book is designed to be a comprehensive resource for students, professionals, and enthusiasts in the field of engineering. It aims to provide a unified perspective on the diverse and complex world of engineering, drawing from a wide range of disciplines and methodologies.

The book is structured around the concept of Unified Engineering, a holistic approach that integrates various engineering disciplines into a cohesive whole. This approach is exemplified by the work of T-Rex Engineering, a leading firm in the field of engineering physics[^38^]. Their work in factory automation infrastructure demonstrates the power of a unified approach, integrating principles from mechanical engineering, electrical engineering, and computer science to create efficient and effective systems.

The book also explores the concept of Unified Modeling Language (UML), a standard language for specifying, visualizing, constructing, and documenting the artifacts of software systems[^12^]. UML is a powerful tool for engineers, allowing them to model both the structure and behavior of systems in a clear and standardized way. The book includes a detailed exploration of the different types of UML diagrams, including structure diagrams, behavior diagrams, and interaction diagrams, each of which provides a different perspective on the system being modeled.

In addition to these practical tools and methodologies, the book also delves into the theoretical underpinnings of Unified Engineering. It explores the concept of metamodeling, a technique for defining the structure and semantics of modeling languages like UML. Metamodeling provides a foundation for understanding and applying these languages, and is a crucial component of a unified approach to engineering.

Throughout the book, we will reference the work of leading figures in the field, such as Alan V. Oppenheim, a pioneer in the field of digital signal processing, and James H. Mulligan, Jr., a leading figure in the field of electrical engineering[^IEEE James H. Mulligan, Jr^]. Their work provides valuable insights and examples that will help to illuminate the concepts and techniques discussed in the book.

We hope that this book will serve as a valuable resource for you, whether you are a student just beginning your journey in engineering, a professional seeking to deepen your understanding, or an enthusiast looking to broaden your knowledge. We invite you to dive in and explore the fascinating world of Unified Engineering.

[^38^]: [Factory automation infrastructure](https://ughb.stanford)
[^12^]: Ottosson, S. Unified Modeling Language.
[^IEEE James H. Mulligan, Jr^]: IEEE James H. Mulligan, Jr. Lean product development.

## Chapter 1: Introduction to Engineering

### Introduction

Engineering is a broad discipline that encompasses a wide range of specialized fields, each with a specific emphasis on particular areas of applied mathematics, applied science, and types of application. This chapter, "Introduction to Engineering," serves as a gateway to the vast world of engineering, providing a general overview of what engineering is, its various branches, and the role it plays in our daily lives.

Engineering is the application of scientific principles to design or develop structures, machines, apparatus, or manufacturing processes, or works utilizing them singly or in combination; or to construct or operate the same with full cognizance of their design; or to forecast their behavior under specific operating conditions; all as respects an intended function, economics of operation and safety to life and property. 

In this chapter, we will explore the historical development of engineering, the fundamental principles that underpin all branches of engineering, and the role of problem-solving in engineering. We will also delve into the ethical considerations that every engineer must take into account in their work. 

We will also discuss the importance of mathematics in engineering. Engineers use mathematics to model real-world situations and to predict the outcomes of their designs. For example, an engineer might use the equation `$F = ma$` to calculate the force needed to accelerate a car at a certain rate.

This chapter serves as a foundation for the rest of the book, which will delve into more specific areas of engineering. By the end of this chapter, you should have a solid understanding of what engineering is and the role it plays in society. This understanding will serve as a foundation for the more specialized knowledge you will gain in later chapters. 

Welcome to the fascinating world of engineering. Let's embark on this journey of discovery together.

### Section: 1.1 Engineering Disciplines

Engineering is a vast field with numerous disciplines, each with its unique focus and application. The main branches of engineering are chemical engineering, civil engineering, electrical engineering, and mechanical engineering. However, there are many other specialized fields within these main branches. 

#### Chemical Engineering

Chemical engineering is a discipline that combines principles of physics, chemistry, biology, and engineering to carry out chemical processes on a commercial scale. These processes include the manufacture of commodity chemicals, specialty chemicals, petroleum refining, microfabrication, fermentation, and biomolecule production. Chemical engineers design, create, and optimize these processes and systems to ensure efficiency, safety, and sustainability.

#### Civil Engineering

Civil engineering is concerned with the design and construction of public and private works. This includes infrastructure such as airports, roads, railways, water supply, and treatment systems, bridges, tunnels, dams, and buildings. Civil engineering is traditionally broken into several sub-disciplines, including structural engineering, environmental engineering, and surveying. It is considered separate from military engineering.

#### Electrical Engineering

Electrical engineering involves the design, study, and manufacture of various electrical and electronic systems. These systems range from broadcast engineering, electrical circuits, generators, motors, electromagnetic/electromechanical devices, electronic devices, electronic circuits, optical fibers, optoelectronic devices, computer systems, telecommunications, instrumentation, control systems, to electronics. Electrical engineers work on a wide range of technologies from tiny microchips to huge power station generators.

#### Mechanical Engineering

Mechanical engineering is one of the oldest and broadest engineering disciplines. It involves the design, analysis, and manufacturing of mechanical systems. This can include anything from small individual parts and devices (like microscale sensors and inkjet printer nozzles) to large systems (like spacecraft and machine tools). The role of a mechanical engineer is to take a product from an idea to the marketplace.

In the following sections, we will delve deeper into each of these disciplines, exploring their history, their current state, and their future prospects. We will also look at how these disciplines intersect and interact with each other, as well as with other fields of study. This will provide a comprehensive understanding of the engineering field as a whole. 

In the next section, we will start with chemical engineering, exploring its principles, applications, and its role in today's world.

### Section: 1.2 Engineering Design Process

The engineering design process is a systematic, iterative method used to solve problems and create innovative solutions in engineering. This process is fundamental to all branches of engineering, from chemical to civil, electrical, and mechanical engineering. It involves a series of steps that engineers follow to come up with a solution to a problem. 

#### The Phases of the Engineering Design Process

The engineering design process typically involves several phases. These phases, as outlined by L. Bruce Archer in his 'Systematic Method for Designers', include the Analytical phase, the Creative phase, and the Executive phase[^1^]. 

1. **Analytical Phase**: This phase involves programming and data collection, as well as analysis. The problem or need for a new design is identified and defined. This phase often involves extensive research to understand the problem fully and to gather all the necessary information to solve it.

2. **Creative Phase**: This phase involves synthesis and development. Potential solutions to the problem are brainstormed and developed. This phase often involves a lot of trial and error as different solutions are tested and refined.

3. **Executive Phase**: This phase involves communication. The final solution is finalized and communicated to the relevant parties. This phase often involves creating detailed plans or prototypes of the solution and presenting them to stakeholders.

These phases are not always linear and often require iteration. Engineers may need to cycle back to earlier phases as new information is discovered or as solutions are tested and refined.

#### Design Methods

Within these process models, there are numerous design methods that can be applied. In his book 'Design Methods', J. C. Jones grouped 26 methods according to their purposes within a design process[^2^]. These methods include stating objectives, investigating user needs, and exploring design situations. The choice of method depends on the specific problem and the engineer's personal approach to problem-solving.

#### The Importance of the Engineering Design Process

The engineering design process is crucial in ensuring that solutions are not only innovative but also safe, efficient, and sustainable. It allows engineers to systematically tackle problems, reducing the risk of oversight and ensuring that all aspects of the problem are considered. Furthermore, by following a structured process, engineers can document their work, making it easier for others to understand their solutions and build upon their work.

[^1^]: Archer, L. B. (1965). Systematic method for designers. Council of Industrial Design.
[^2^]: Jones, J. C. (1970). Design Methods: seeds of human futures. Wiley-Interscience.

### Section: 1.3 Problem Solving Techniques

Engineering is not just about designing and building things; it's also about solving problems. Engineers often encounter complex problems that require innovative solutions. This section will introduce some problem-solving techniques that are commonly used in engineering.

#### Unified Structured Inventive Thinking (USIT)

Unified Structured Inventive Thinking (USIT) is a problem-solving methodology that encourages the rapid application of intuitive problem solving and the quick collection of "low hanging fruit". It is recommended to turn to USIT after conventional methodologies have waned[^3^].

USIT fits between problem identification and the selection of solution concepts found for a problem; both involve engineering and business decisions. Between these engineering-filtering events, a problem solver is free of such filters while searching solution concepts to be engineered[^3^].

USIT emphasizes this distinct division enabling a problem solver to spend time focused on creative thinking without psychologically inhibiting filters—a problem simplification strategy[^3^].

All aspects of USIT are derived from a unifying theory based on three fundamental components: objects, attributes, and the effects they support. Effects may be beneficial, called "functions", or not beneficial, called "unwanted effects"[^3^].

The methodology consists of three common phases: "problem definition", "problem analysis", and "application of solution concepts" with equal time spent in each phase[^3^].

Five solution heuristics are used to support these strategies[^3^]: 

1. **Dimensionality**: This heuristic focuses on the "attributes" available and new ones discovered during problem analysis. 

2. **Pluralization**: This heuristic focuses on "objects" being multiplied in number or divided into parts, used in different ways, and carried to extreme.

#### Decomposition Method

Decomposition is another problem-solving technique that is often used in engineering. This method involves breaking down a complex problem into smaller, more manageable parts. Each part can then be solved individually, and the solutions can be combined to solve the original problem.

Decomposition is particularly useful in constraint satisfaction problems, where the goal is to find a solution that satisfies a set of constraints. By breaking down the problem into smaller parts, it is often possible to simplify the constraints and make the problem easier to solve[^4^].

#### Brainstorming

Brainstorming is a widely used problem-solving technique that involves generating a large number of ideas in order to find a solution to a problem. This technique is often used in the creative phase of the engineering design process, as it encourages free thinking and the exploration of a wide range of potential solutions[^5^].

During a brainstorming session, all ideas are welcomed, and criticism is discouraged. This encourages participants to think outside the box and propose innovative solutions that might not be considered in a more structured problem-solving process[^5^].

In conclusion, problem-solving is a critical skill in engineering. By understanding and applying these techniques, engineers can develop innovative solutions to complex problems.

[^3^]: Sickafus, E. N. (1997). Unified Structured Inventive Thinking: How to Invent. Ntelleck.
[^4^]: Dechter, R. (2003). Constraint Processing. Morgan Kaufmann.
[^5^]: Osborn, A. F. (1953). Applied Imagination: Principles and Procedures of Creative Problem-Solving. Scribner.

### Conclusion

In this introductory chapter, we have laid the groundwork for understanding the broad and diverse field of engineering. We have explored the fundamental principles that underpin all engineering disciplines, and we have seen how these principles are applied in a variety of contexts. We have also discussed the importance of a unified approach to engineering, which allows us to see the connections between different areas of engineering and to apply our knowledge in a flexible and adaptable way.

As we move forward in this book, we will delve deeper into these topics, exploring the specific techniques and methodologies used in different areas of engineering. We will also look at how these techniques are evolving in response to new challenges and opportunities, such as the increasing importance of sustainability and the rapid advances in technology.

Remember, the goal of this book is not just to provide you with a set of facts and formulas, but to help you develop a deep and intuitive understanding of engineering. This understanding will enable you to solve complex problems, to innovate, and to contribute to the advancement of engineering knowledge.

#### Exercise 1
Define engineering in your own words. What are the key principles that underpin all engineering disciplines?

#### Exercise 2
Discuss the importance of a unified approach to engineering. How does this approach benefit engineers and the field of engineering as a whole?

#### Exercise 3
Choose a specific area of engineering (e.g., civil, mechanical, electrical, etc.). Research and write a brief summary of the key techniques and methodologies used in this area.

#### Exercise 4
Discuss the role of technology in engineering. How is technology changing the way engineers work and the types of problems they can solve?

#### Exercise 5
Reflect on the importance of sustainability in engineering. How can engineers contribute to sustainability, and what challenges do they face in doing so?

## Chapter: Statics and Dynamics

### Introduction

Welcome to Chapter 2: Statics and Dynamics. This chapter is designed to provide a comprehensive understanding of the fundamental principles of statics and dynamics, two crucial branches of mechanics in the field of Unified Engineering. 

Statics, as the name suggests, is the study of bodies at rest. It delves into the analysis of forces acting on and within structures that are in equilibrium. On the other hand, dynamics is concerned with the motion of bodies under the action of forces. Both statics and dynamics are fundamental to the design and analysis of engineering systems, from the smallest mechanical devices to the largest structures.

In this chapter, we will explore the laws of statics and dynamics, starting with the basic principles and gradually moving towards more complex applications. We will delve into the concepts of force, mass, acceleration, work, energy, and power, and understand how they interact in both static and dynamic systems.

We will also explore the mathematical representations of these principles. For instance, Newton's second law, which states that the force acting on an object is equal to its mass times its acceleration, can be represented as `$F = ma$`. Similarly, the work done by a force can be represented as `$W = Fd$`, where `$F$` is the force and `$d$` is the distance over which the force is applied.

By the end of this chapter, you should have a solid understanding of the principles of statics and dynamics, and be able to apply these principles to solve engineering problems. This knowledge will serve as a foundation for the subsequent chapters, where we will delve deeper into the various branches of Unified Engineering.

Remember, the key to mastering these concepts is practice. So, don't hesitate to apply what you learn in this chapter to practical problems, and don't be afraid to make mistakes. After all, engineering is all about learning from our mistakes and finding solutions to complex problems. Let's get started!

### Section: 2.1 Forces and Moments

In this section, we will delve deeper into the concepts of forces and moments, which are fundamental to the study of statics and dynamics. 

#### Forces

A force is a vector quantity that tends to move an object in the direction of its action. The force acting on an object can be represented as `$F$`, and it has both magnitude and direction. Forces can cause an object to accelerate, decelerate, or change direction, according to Newton's second law of motion, which can be represented as `$F = ma$`, where `$m$` is the mass of the object and `$a$` is its acceleration.

In the context of statics, forces are balanced to maintain a system in equilibrium. This means that the sum of all forces acting on the system is zero, which can be represented as `$\sum F = 0$`. In the context of dynamics, forces cause changes in the motion of objects.

#### Moments

A moment, or torque, is a measure of the tendency of a force to cause rotation about a point or axis. The moment of a force `$F$` about a point can be calculated by multiplying the force by the perpendicular distance `$d$` from the point to the line of action of the force. This can be represented as `$M = Fd$`.

In the context of statics, moments are balanced to maintain a system in rotational equilibrium. This means that the sum of all moments acting on the system is zero, which can be represented as `$\sum M = 0$`. In the context of dynamics, moments cause changes in the rotational motion of objects.

#### Forces and Moments in Engineering

Understanding forces and moments is crucial in engineering. For instance, in structural engineering, the forces and moments acting on a structure must be calculated to ensure that the structure can withstand them. This involves creating a free body diagram of the structure, identifying all forces and moments, and ensuring that they are balanced.

In the context of the shear and moment diagram mentioned earlier, the reaction forces and moments at the supports and the clamped end of the beam are calculated using the balance of forces and moments in the beam. This involves summing the forces and moments, and solving the resulting equations to find the unknowns.

In the next section, we will delve deeper into the concept of equilibrium and explore how it is used to analyze static systems.

# NOTE - THIS TEXTBOOK WAS AI GENERATED

This textbook was generated using AI techniques. While it aims to be factual and accurate, please verify any critical information. The content may contain errors, biases or harmful content despite best efforts. Please report any issues.

# NOTE - THIS TEXTBOOK WAS AI GENERATED

This textbook was generated using AI techniques. While it aims to be factual and accurate, please verify any critical information. The content may contain errors, biases or harmful content despite best efforts. Please report any issues.

# NOTE - THIS TEXTBOOK WAS AI GENERATED

This textbook was generated using AI techniques. While it aims to be factual and accurate, please verify any critical information. The content may contain errors, biases or harmful content despite best efforts. Please report any issues.

# Comprehensive Guide to Unified Engineering":

## Foreward

Welcome to the "Comprehensive Guide to Unified Engineering", a book designed to provide a holistic understanding of the vast and complex field of engineering. This book is a culmination of knowledge from various engineering disciplines, unified under a single umbrella, to provide a comprehensive understanding of the principles, practices, and applications of engineering.

The book is structured to provide a seamless transition from basic concepts to advanced topics, making it suitable for both beginners and experienced professionals. It covers a wide range of topics, from the fundamental principles of engineering physics to the intricate details of factory automation infrastructure. The book also delves into the realm of lean product development, a modern approach to product development that emphasizes efficiency and waste reduction.

One of the key features of this book is its focus on Unified Modeling Language (UML), a standard language for specifying, visualizing, constructing, and documenting the artifacts of software systems. UML is a powerful tool that can help engineers understand, design, and manage complex systems. The book provides an in-depth exploration of UML, including its various diagram types and their uses in representing structural and behavioral aspects of a system.

The book also introduces the concept of metamodeling, a technique used to define the language for expressing a model. Metamodeling is a crucial aspect of unified engineering, as it allows for the creation of more precise and effective models.

Throughout the book, you will find numerous references and external links that provide additional information and context. These resources have been carefully selected to complement the content of the book and provide a more comprehensive understanding of the topics discussed.

This book is not just a guide; it is a journey through the world of unified engineering. It is designed to inspire, educate, and challenge you, pushing the boundaries of your understanding and encouraging you to explore new horizons in the field of engineering.

Whether you are a student, a professional, or simply an enthusiast, this book will serve as a valuable resource in your quest for knowledge. So, let's embark on this journey together, exploring the fascinating world of unified engineering.

Welcome aboard!

## Chapter 1: Introduction to Engineering

### Introduction

Engineering is a broad discipline that encompasses a wide range of fields, each with its unique principles, tools, and methodologies. This chapter, "Introduction to Engineering," aims to provide a comprehensive overview of the fundamental concepts and principles that underpin the field of engineering. 

The chapter will explore the historical development of engineering, highlighting the significant milestones and innovations that have shaped the discipline over the centuries. It will delve into the various branches of engineering, such as civil, mechanical, electrical, and chemical engineering, among others, providing a brief overview of each. 

The chapter will also introduce the concept of the engineering design process, a systematic, iterative approach used by engineers to solve complex problems. This process, often represented as a cycle, involves several stages, including problem identification, research, idea generation, prototyping, testing, and refinement. 

Moreover, the chapter will discuss the role of mathematics and science in engineering. Engineers often use mathematical models and scientific principles to predict the behavior of systems and to design and optimize solutions. For instance, an engineer might use the equation `$F = ma$` (Force equals mass times acceleration) to design a bridge that can withstand specific loads.

Finally, the chapter will touch on the ethical and societal implications of engineering. Engineers have a responsibility to ensure that their work is safe, sustainable, and beneficial to society. They must also adhere to a code of ethics that guides their professional conduct.

This chapter serves as a stepping stone into the world of engineering, providing a solid foundation upon which to build further knowledge and understanding. Whether you are a student just starting your engineering journey or a seasoned professional seeking to refresh your knowledge, this chapter offers valuable insights into the fascinating world of engineering.

### Section: 1.1 Engineering Disciplines

Engineering is a vast field with numerous sub-disciplines, each with its unique principles, methodologies, and applications. This section will provide a brief overview of the four main branches of engineering: chemical, civil, electrical, and mechanical engineering.

#### Chemical Engineering

Chemical engineering is a discipline that combines principles from physics, chemistry, biology, and engineering to carry out chemical processes on a commercial scale. These processes include the manufacture of commodity chemicals, specialty chemicals, petroleum refining, microfabrication, fermentation, and biomolecule production. Chemical engineers design, create, and optimize these processes, often using mathematical models and scientific principles to predict system behavior and improve efficiency.

#### Civil Engineering

Civil engineering involves the design and construction of public and private works, including infrastructure (airports, roads, railways, water supply, and treatment etc.), bridges, tunnels, dams, and buildings. It is traditionally divided into several sub-disciplines, such as structural engineering, environmental engineering, and surveying. Civil engineers use mathematical and scientific principles to design structures that can withstand specific loads and environmental conditions. For instance, they might use the equation `$F = ma$` (Force equals mass times acceleration) to design a bridge that can withstand specific loads.

#### Electrical Engineering

Electrical engineering encompasses the design, study, and manufacture of various electrical and electronic systems. These systems include broadcast engineering, electrical circuits, generators, motors, electromagnetic/electromechanical devices, electronic devices, electronic circuits, optical fibers, optoelectronic devices, computer systems, telecommunications, instrumentation, control systems, and electronics. Electrical engineers use mathematical models and scientific principles to design and optimize these systems, ensuring they operate efficiently and safely.

#### Mechanical Engineering

Mechanical engineering is the discipline that involves the design, analysis, manufacturing, and maintenance of mechanical systems. This branch of engineering requires a deep understanding of core concepts including mechanics, kinematics, thermodynamics, materials science, and structural analysis. Mechanical engineers use these principles, along with tools like computer-aided design (CAD) and product lifecycle management to design and analyze manufacturing plants, industrial equipment and machinery, heating and cooling systems, transport systems, aircraft, watercraft, robotics, medical devices, and more.

In the following sections, we will delve deeper into each of these disciplines, exploring their historical development, key principles, methodologies, and applications. We will also discuss the role of mathematics and science in each discipline, providing examples of how engineers use mathematical models and scientific principles to solve complex problems.

### Section: 1.2 Engineering Design Process

The engineering design process is a systematic, iterative method used to solve problems and create innovative solutions in engineering. This process is fundamental to all branches of engineering, and it is what distinguishes engineering from pure science. While science seeks to understand the natural world, engineering seeks to apply scientific principles to design and build solutions that meet human needs and desires.

The engineering design process typically involves several stages, although the exact number and nature of these stages can vary depending on the specific method used. However, most models of the engineering design process include some version of the following stages:

1. **Problem Definition**: This is the initial stage where the engineer identifies a need or problem that needs to be addressed. This stage involves understanding the problem in detail, defining the requirements and constraints, and establishing clear and measurable objectives for the solution.

2. **Research and Analysis**: In this stage, the engineer gathers information about the problem and its context. This can involve researching existing solutions, understanding relevant scientific principles, and collecting data about the problem and its constraints.

3. **Conceptual Design**: This is the creative stage where the engineer generates a range of possible solutions to the problem. These solutions are usually represented as conceptual models or sketches, and they are evaluated based on their feasibility, effectiveness, and compliance with the defined requirements and constraints.

4. **Detailed Design**: Once a conceptual design has been selected, it is developed into a detailed design. This involves specifying the exact dimensions, materials, and manufacturing processes that will be used to create the solution.

5. **Prototype and Testing**: The detailed design is then turned into a physical prototype, which is tested to see if it meets the defined objectives. The results of these tests are used to refine the design and correct any flaws or weaknesses.

6. **Implementation**: Once the design has been tested and refined, it is implemented. This could involve manufacturing a product, constructing a structure, or installing a system.

7. **Evaluation and Iteration**: After the solution has been implemented, it is evaluated to see if it meets the defined objectives. If it does not, the engineer returns to an earlier stage in the process and makes necessary adjustments. This iterative nature is a key feature of the engineering design process.

It's important to note that these stages are not always linear. Often, engineers will need to loop back to earlier stages as new information becomes available or as problems arise. This iterative process is what allows engineers to continually improve their designs and adapt to changing conditions and requirements.

In the next section, we will delve deeper into each of these stages, providing a more detailed look at the methods and techniques used in the engineering design process.

### Section: 1.3 Problem Solving Techniques

In the field of engineering, problem-solving is a critical skill. It involves the application of scientific principles, mathematical methods, and innovative thinking to find solutions to complex problems. This section will introduce some of the most common problem-solving techniques used in engineering, including the Unified Structured Inventive Thinking (USIT) methodology.

#### Unified Structured Inventive Thinking (USIT)

USIT is a problem-solving methodology that encourages the rapid application of intuitive problem solving, often referred to as brainstorming, and the quick collection of "low hanging fruit". It is typically applied after conventional methodologies have been exhausted. USIT emphasizes the distinct division between problem identification and the selection of solution concepts, allowing a problem solver to focus on creative thinking without psychologically inhibiting filters. This is often referred to as a problem simplification strategy.

USIT is based on three fundamental components: objects, attributes, and the effects they support. Effects may be beneficial, referred to as "functions", or not beneficial, referred to as "unwanted effects". The methodology consists of three common phases: "problem definition", "problem analysis", and "application of solution concepts", with equal time spent in each phase.

Five solution heuristics are used to support these strategies:

1. **Dimensionality**: This heuristic focuses on the "attributes" available and new ones discovered during problem analysis.

2. **Pluralization**: This heuristic focuses on "objects" being multiplied in number or divided into parts, used in different ways, and carried to extreme.

The other three heuristics will be discussed in the following sections.

#### Decomposition Method

Decomposition is another problem-solving technique commonly used in engineering. It involves breaking down a complex problem into smaller, more manageable parts. This method is particularly useful in constraint satisfaction problems, where the goal is to find a solution that satisfies a set of constraints.

#### Brainstorming

Brainstorming is a widely used technique for generating creative solutions to a problem. It involves a group of people freely suggesting ideas, with the aim of sparking off each other's creativity and coming up with innovative solutions. The key to successful brainstorming is to encourage free thinking and discourage criticism of ideas during the brainstorming session.

In the next section, we will delve deeper into the engineering problem-solving process, discussing each stage in detail and providing practical examples.

### Conclusion

In this introductory chapter, we have laid the groundwork for understanding the broad and diverse field of engineering. We have explored the fundamental principles that underpin all engineering disciplines, and have begun to see how these principles can be applied in a unified manner to solve complex problems. We have also discussed the importance of creativity, innovation, and ethical considerations in engineering practice. 

As we move forward in this book, we will delve deeper into each of these topics, exploring them in greater detail and providing practical examples of how they are applied in real-world engineering scenarios. We will also introduce more advanced concepts and techniques, building on the foundation we have established in this chapter. 

Remember, the field of engineering is constantly evolving, and as a future engineer, it is important to stay abreast of the latest developments and trends. This book is designed to provide you with a comprehensive understanding of engineering, but it is only the beginning of your journey. 

### Exercises

#### Exercise 1
Define engineering in your own words. What are the key principles that underpin all engineering disciplines?

#### Exercise 2
Discuss the role of creativity and innovation in engineering. Provide examples of how these elements can contribute to the success of an engineering project.

#### Exercise 3
Discuss the ethical considerations that must be taken into account in engineering practice. Why is ethics important in engineering?

#### Exercise 4
Research and write a brief report on a recent development or trend in the field of engineering. How does this development or trend reflect the principles and practices discussed in this chapter?

#### Exercise 5
Reflect on your own interests and career goals. How do you see the principles and practices of engineering being applied in your chosen field?

## Chapter: Statics and Dynamics

### Introduction

Welcome to Chapter 2: Statics and Dynamics. This chapter is designed to provide a comprehensive understanding of the fundamental principles of statics and dynamics, two crucial branches of mechanics in the field of unified engineering. 

Statics, as the name suggests, is the study of forces in equilibrium. In this branch of mechanics, we delve into the analysis of bodies at rest or moving at a constant velocity. It is a field that provides the foundation for the study of structures, from simple mechanical systems to complex architectural marvels. 

On the other hand, dynamics is the study of forces and the motion they cause. This branch of mechanics is concerned with the analysis of bodies in motion under the action of forces. It is a field that underpins the study of various mechanical systems, from simple pendulums to complex machinery.

In this chapter, we will explore the fundamental principles of statics and dynamics, starting with the basic concepts and gradually moving towards more complex applications. We will delve into the laws of motion, force analysis, equilibrium conditions, and various other topics that form the core of these subjects. 

The mathematical expressions and equations in this chapter will be formatted using the TeX and LaTeX style syntax. For instance, inline math will be written as `$y_j(n)$` and equations will be written as `$$ \Delta w = ... $$`. This will ensure that the mathematical content is rendered accurately and is easy to understand.

By the end of this chapter, you should have a solid understanding of the principles of statics and dynamics, and be able to apply these principles to solve engineering problems. This knowledge will serve as a foundation for the subsequent chapters and for your future studies in unified engineering.

### Section: 2.1 Forces and Moments

In this section, we will delve into the concepts of forces and moments, two fundamental aspects of statics and dynamics. Understanding these concepts is crucial for the analysis of mechanical systems and structures.

#### 2.1.1 Forces

A force is a vector quantity that tends to move an object in the direction of its action. The force vector is characterized by its magnitude, direction, and point of application. In statics, we are primarily concerned with the balance of forces, which leads to the condition of equilibrium. In dynamics, forces are the cause of motion and changes in motion.

The sum of forces acting on a body is given by the equation:

$$
\sum F = 0
$$

This equation represents the condition of equilibrium in statics. If the sum of forces is not zero, the body will accelerate in the direction of the resultant force, as per Newton's second law of motion.

#### 2.1.2 Moments

A moment, or torque, is a measure of the tendency of a force to rotate an object about an axis. The moment of a force about a point is the product of the force and the perpendicular distance from the point to the line of action of the force. 

The sum of moments about a point is given by the equation:

$$
\sum M = 0
$$

This equation represents the rotational equilibrium condition. If the sum of moments is not zero, the body will experience angular acceleration.

In the context of the shear and moment diagram, we use the balance of forces and moments to determine the reaction forces and moments at the supports and the clamped end of the beam. This is a crucial step in the analysis of statically indeterminate beams, as it allows us to break down the problem into a superposition of statically determinate problems.

For instance, consider a beam with reaction forces $R_a$, $R_b$, and $R_c$, and a reaction couple $M_c$. From the free-body diagram of the entire beam, we can write the balance equations as follows:

Summing the forces:

$$
R_a + R_b + R_c = 0
$$

And summing the moments about the free end (A):

$$
R_a(10) + R_b(25) + R_c(50) - (1)(15)(17.5) -50 + M_c= 0
$$

These equations can be solved to find the reaction forces and moments in terms of the given quantities. This process is fundamental to the analysis of forces and moments in statics and dynamics.

### Section: 2.2 Equilibrium

In the previous section, we discussed the fundamental concepts of forces and moments, and how they play a crucial role in the analysis of mechanical systems and structures. In this section, we will delve deeper into the concept of equilibrium, a state where all forces and moments acting on a body are balanced.

#### 2.2.1 Conditions of Equilibrium

For a body to be in equilibrium, two conditions must be satisfied:

1. The vector sum of all forces acting on the body must be zero. This is known as the translational equilibrium condition, represented mathematically as:

$$
\sum F = 0
$$

2. The sum of all moments about any point must also be zero. This is known as the rotational equilibrium condition, represented mathematically as:

$$
\sum M = 0
$$

These conditions ensure that the body does not experience any linear or angular acceleration.

#### 2.2.2 Equations of Equilibrium

The equations of equilibrium are derived from the conditions of equilibrium. For instance, the Föppl–von Kármán equations, which are fundamental in the study of large deflections of plates, are derived from the equilibrium conditions. These equations are typically derived with an energy approach by considering variations of internal energy and the virtual work done by external forces.

The weak form of the Kirchhoff plate, which is a part of the Föppl–von Kármán equations, is given by:

$$
\begin{align*}
&+ \int_{\Omega} N_{11}\frac{\partial\delta v_1}{\partial x_1} + N_{12}\frac{\partial\delta v_1}{\partial x_2}\,d\Omega = -\int_{\Omega} p_1 \delta v_1 \,d\Omega \\
&+ \int_{\Omega} N_{22}\frac{\partial\delta v_2}{\partial x_2} + N_{12}\frac{\partial\delta v_2}{\partial x_1}\,d\Omega = -\int_{\Omega} p_2 \delta v_2 \,d\Omega \\
&+ \int_{\Omega} N_{11}\frac{\partial w}{\partial x_1}\frac{\partial\delta w}{\partial x_1} - M_{11}\frac{\partial^2 \delta w}{\partial^2 x_1} \,d\Omega\\
&+ \int_{\Omega} N_{22}\frac{\partial w}{\partial x_2}\frac{\partial\delta w}{\partial x_2} - M_{22}\frac{\partial^2 \delta w}{\partial^2 x_2} \,d\Omega\\
&+ \int_{\Omega} N_{12}\left(\frac{\partial \delta w}{\partial x_1}\frac{\partial\delta w}{\partial x_2} + \frac{\partial w}{\partial x_1}\frac{\partial\delta w}{\partial x_2}\right) - 2M_{12}\frac{\partial^2 \delta w}{\partial x_1\partial x_2} \,d\Omega = -\int_{\Omega} p_3 \delta w \,d\Omega\\
\end{align*}
$$

These equations represent the equilibrium of forces and moments in the plate. The terms $N_{11}$, $N_{22}$, and $N_{12}$ are the stress resultants, $p_1$, $p_2$, and $p_3$ are the external loads, and $v_1$, $v_2$, and $w$ are the displacements in the $x_1$, $x_2$, and $x_3$ directions, respectively.

In the next section, we will discuss the concept of free body diagrams, a graphical representation of the forces and moments acting on a body, which is a crucial tool in the analysis of equilibrium.

### Section: 2.3 Free Body Diagrams

After understanding the concept of equilibrium, we now move on to a crucial tool used in the analysis of forces and moments acting on a body: the Free Body Diagram (FBD). An FBD is a graphical representation of a body or a system of bodies isolated from its surroundings, showing all the external forces and moments acting on it.

#### 2.3.1 Constructing a Free Body Diagram

The process of constructing an FBD involves several steps:

1. **Isolate the Body**: The first step is to isolate the body from its surroundings. This involves mentally 'cutting' the body free from any objects it is in contact with and removing any supports or constraints.

2. **Identify Forces**: Next, identify all the forces acting on the body. This includes both contact forces (such as friction or normal force) and body forces (such as gravity or magnetic force).

3. **Represent Forces**: Each force is then represented as a vector, with its tail at the point of application and its head pointing in the direction of the force. The length of the vector is proportional to the magnitude of the force.

4. **Identify Moments**: If there are any moments acting on the body, identify them and represent them as curved arrows, with the direction of the arrow indicating the direction of rotation.

5. **Add Reference Frame**: Finally, add a reference frame to the diagram to indicate the orientation of the body and the direction of the forces and moments.

#### 2.3.2 Using a Free Body Diagram

Once the FBD is constructed, it can be used to apply the conditions of equilibrium and solve for unknown forces or moments. This is done by summing the forces in each direction and setting them equal to zero (for translational equilibrium), and summing the moments about any point and setting them equal to zero (for rotational equilibrium). Mathematically, this can be represented as:

$$
\sum F_x = 0
$$

$$
\sum F_y = 0
$$

$$
\sum M = 0
$$

Where $F_x$ and $F_y$ are the components of the forces in the x and y directions, respectively, and M is the moment.

In the next section, we will discuss how to apply these principles to solve statics problems involving multiple bodies and complex loading conditions.

### Section: 2.4 Newton's Laws of Motion

Newton's laws of motion are three fundamental principles that describe the relationship between the motion of an object and the forces acting on it. These laws were first stated by Sir Isaac Newton in his work "Philosophiæ Naturalis Principia Mathematica" published in 1687. They form the foundation of classical mechanics and have been used to explain the motion of various physical objects and systems.

#### 2.4.1 Newton's First Law of Motion

The first law, also known as the law of inertia, states that an object at rest tends to stay at rest, and an object in motion tends to stay in motion, with the same speed and in the same direction, unless acted upon by a net external force. Mathematically, this can be represented as:

$$
\sum F = 0 \Rightarrow \frac{d\vec{v}}{dt} = 0
$$

Where $\sum F$ is the sum of all external forces acting on the object, $\vec{v}$ is the velocity of the object, and $\frac{d\vec{v}}{dt}$ is the rate of change of velocity (acceleration).

#### 2.4.2 Newton's Second Law of Motion

The second law states that the rate of change of momentum of an object is directly proportional to the net external force acting on it, and the change occurs in the direction in which the force is applied. This law can be expressed mathematically as:

$$
\sum F = m \frac{d\vec{v}}{dt}
$$

Where $m$ is the mass of the object, and $\sum F$ and $\frac{d\vec{v}}{dt}$ are as defined above.

#### 2.4.3 Newton's Third Law of Motion

The third law, also known as the law of action and reaction, states that for every action, there is an equal and opposite reaction. This means that any force exerted on a body will create a force of equal magnitude but in the opposite direction on the object that exerted the first force. Mathematically, this can be represented as:

$$
\vec{F}_{12} = -\vec{F}_{21}
$$

Where $\vec{F}_{12}$ is the force exerted by object 1 on object 2, and $\vec{F}_{21}$ is the force exerted by object 2 on object 1.

These laws are often stated in terms of "point" or "particle" masses, that is, bodies whose volume is negligible. This is a reasonable approximation for real bodies when the motion of internal parts can be neglected, and when the separation between bodies is much larger than the size of each.

In the next section, we will explore how these laws can be applied to solve problems in statics and dynamics.

### Section: 2.5 Kinematics

Kinematics is the branch of physics that describes the motion of points, bodies (objects), and systems of bodies without considering the forces that cause them to move. It involves the study of position, velocity, and acceleration, and their relationships with each other through calculus.

#### 2.5.1 Position and Displacement

The position of an object is its location in space. It is usually described in terms of a coordinate system. The displacement of an object is the change in its position. It is a vector quantity, meaning it has both magnitude and direction. Mathematically, displacement ($\vec{d}$) can be represented as:

$$
\vec{d} = \vec{r}_f - \vec{r}_i
$$

Where $\vec{r}_f$ is the final position, and $\vec{r}_i$ is the initial position.

#### 2.5.2 Velocity and Speed

Velocity is the rate of change of displacement with respect to time. It is also a vector quantity. The magnitude of the velocity vector is the speed of the object. Mathematically, velocity ($\vec{v}$) can be represented as:

$$
\vec{v} = \frac{d\vec{r}}{dt}
$$

Where $d\vec{r}$ is the displacement, and $dt$ is the change in time.

#### 2.5.3 Acceleration

Acceleration is the rate of change of velocity with respect to time. It is a vector quantity. Mathematically, acceleration ($\vec{a}$) can be represented as:

$$
\vec{a} = \frac{d\vec{v}}{dt}
$$

Where $d\vec{v}$ is the change in velocity, and $dt$ is the change in time.

#### 2.5.4 Motion in One Dimension

In one-dimensional motion, the direction of motion can be represented by a positive or negative sign. The equations of motion can be derived from the definitions of velocity and acceleration. For an object with constant acceleration, the equations of motion are:

$$
\vec{v} = \vec{v}_i + \vec{a}t
$$

$$
\vec{d} = \vec{v}_i t + \frac{1}{2}\vec{a}t^2
$$

Where $\vec{v}_i$ is the initial velocity, $\vec{a}$ is the acceleration, and $t$ is the time.

#### 2.5.5 Motion in Two Dimensions

In two-dimensional motion, the motion occurs in a plane. The position, velocity, and acceleration vectors have two components: one in the x-direction and one in the y-direction. The motion in each direction is independent of the motion in the other direction. The equations of motion in each direction are the same as those for one-dimensional motion.

Kinematics is a fundamental concept in the study of motion, providing the tools to describe and analyze motion. In the next section, we will explore dynamics, which introduces the causes of motion - forces.

### Section: 2.6 Energy and Momentum

Energy and momentum are fundamental concepts in physics and engineering. They are conserved quantities, meaning that in a closed system, their total amount remains constant. This principle of conservation is a powerful tool for analyzing physical systems and solving engineering problems.

#### 2.6.1 Energy

Energy is the capacity to do work. It can exist in various forms such as kinetic energy, potential energy, thermal energy, and more. The total energy of a system is the sum of all these forms. The principle of conservation of energy states that energy cannot be created or destroyed, only transferred or converted from one form to another. Mathematically, this can be represented as:

$$
\Delta E = \Delta K + \Delta U + \Delta Q
$$

Where $\Delta E$ is the change in total energy, $\Delta K$ is the change in kinetic energy, $\Delta U$ is the change in potential energy, and $\Delta Q$ is the heat transferred.

#### 2.6.2 Momentum

Momentum is a vector quantity that depends on both the mass and velocity of an object. The principle of conservation of momentum states that the total momentum of a closed system remains constant unless acted upon by an external force. Mathematically, this can be represented as:

$$
\vec{p} = m\vec{v}
$$

Where $\vec{p}$ is the momentum, $m$ is the mass, and $\vec{v}$ is the velocity.

### Subsection: 2.6a Friction and Coefficients

Friction is a force that resists the relative motion of two surfaces in contact. It plays a crucial role in many engineering applications, from the operation of machinery to the design of structures.

#### Coefficient of Friction

The coefficient of friction (COF), often symbolized by the Greek letter $\mu$, is a scalar value that describes the ratio of the force of friction between two bodies to the force pressing them together. It depends on the materials used for the two surfaces in contact. The COF is usually determined experimentally.

There are two types of COF: static and kinetic. The static COF is the friction that needs to be overcome to start moving, and the kinetic COF is the friction that resists motion. Mathematically, the force of friction ($F_f$) can be represented as:

$$
F_f = \mu F_n
$$

Where $F_f$ is the force of friction, $\mu$ is the COF, and $F_n$ is the normal force.

### Section: 2.6b Circular Motion

Circular motion is a fundamental concept in physics and engineering, particularly in fields such as aerospace engineering and mechanical engineering. It describes the motion of an object along the circumference of a circle or any circular path.

#### Centripetal Acceleration

In circular motion, the velocity of the object is constantly changing because its direction is continuously changing. This change in velocity results in an acceleration known as centripetal acceleration. Centripetal acceleration always points towards the center of the circle and is given by the equation:

$$
a_c = \frac{v^2}{r}
$$

Where $a_c$ is the centripetal acceleration, $v$ is the speed of the object, and $r$ is the radius of the circular path.

#### Angular Velocity

Angular velocity, often denoted by $\omega$, is the rate of change of the angle that the moving object subtends at the center of the circle. It is given by the equation:

$$
\omega = \frac{d\theta}{dt}
$$

Where $\omega$ is the angular velocity, $d\theta$ is the change in the angle, and $dt$ is the change in time. 

#### Relativistic Circular Motion

In the context of relativistic physics, the three-acceleration vector is perpendicular to the three-velocity vector, and the square of proper acceleration, expressed as a scalar invariant, becomes the expression for circular motion:

$$
\alpha^2 = \gamma^4 a^2
$$

Taking the positive square root and using the three-acceleration, we arrive at the proper acceleration for circular motion:

$$
\alpha = \gamma^2 \frac{v^2}{r}
$$

Where $\alpha$ is the proper acceleration, $\gamma$ is the Lorentz factor, $v$ is the speed of the object, and $r$ is the radius of the circular path.

#### Applications of Circular Motion

Circular motion principles are applied in various engineering fields. For instance, in aerospace engineering, the rotation of a spacecraft in orbit can be visualized using Poinsot's construction, a concept based on circular motion. In mechanical engineering, the design and operation of rotating machinery such as engines and turbines rely heavily on the principles of circular motion.

### Section: 2.6c Rotational Dynamics

Rotational dynamics, also known as angular dynamics, is a branch of physics that deals with the rotation of rigid bodies. It is a counterpart to linear dynamics, which deals with the motion of objects along a straight line. In this section, we will explore the concepts of torque, moment of inertia, angular momentum, and energy in rotational motion.

#### Torque

Torque, often denoted by $\tau$, is the rotational equivalent of force. It is a measure of the force that can cause an object to rotate about an axis. The torque exerted by a force $F$ acting at a distance $r$ from the pivot point is given by the equation:

$$
\tau = r \times F
$$

Where $\tau$ is the torque, $r$ is the distance from the pivot point to the point where the force is applied, and $F$ is the force.

#### Moment of Inertia

The moment of inertia, often denoted by $I$, is the rotational equivalent of mass. It is a measure of an object's resistance to changes in its rotational motion. The moment of inertia of a point mass $m$ at a distance $r$ from the axis of rotation is given by the equation:

$$
I = m \times r^2
$$

Where $I$ is the moment of inertia, $m$ is the mass of the object, and $r$ is the distance from the axis of rotation.

#### Angular Momentum

Angular momentum, often denoted by $L$, is the rotational equivalent of linear momentum. It is a measure of the amount of rotation an object has. The angular momentum of an object with moment of inertia $I$ and angular velocity $\omega$ is given by the equation:

$$
L = I \times \omega
$$

Where $L$ is the angular momentum, $I$ is the moment of inertia, and $\omega$ is the angular velocity.

#### Energy in Rotational Motion

The kinetic energy of an object in rotational motion is given by the equation:

$$
K = \frac{1}{2} I \omega^2
$$

Where $K$ is the kinetic energy, $I$ is the moment of inertia, and $\omega$ is the angular velocity.

#### Applications of Rotational Dynamics

Rotational dynamics principles are applied in various engineering fields. For instance, in mechanical engineering, the design of gears, pulleys, and flywheels relies heavily on the principles of rotational dynamics. In aerospace engineering, the stability and control of spacecraft involve the application of rotational dynamics. Understanding rotational dynamics is also crucial in the study of celestial bodies, as it helps us understand their rotation and the forces acting on them.

### Section: 2.6 Energy and Momentum

In this section, we will explore the concepts of energy and momentum in the context of statics and dynamics. We will start by defining these terms and then delve into their applications in the field of unified engineering.

#### Energy

Energy, often denoted by $E$, is a fundamental concept in physics. It is a scalar quantity that describes the amount of work that can be performed by a force. Energy can exist in various forms such as kinetic energy, potential energy, thermal energy, etc. The law of conservation of energy states that energy cannot be created or destroyed, only transferred or converted from one form to another.

The kinetic energy of an object of mass $m$ moving with a velocity $v$ is given by the equation:

$$
K = \frac{1}{2} m v^2
$$

Where $K$ is the kinetic energy, $m$ is the mass of the object, and $v$ is its velocity.

Potential energy, on the other hand, is the energy stored in an object due to its position in a force field or due to its configuration. For example, an object at a height $h$ in a gravitational field of strength $g$ has a gravitational potential energy given by:

$$
U = mgh
$$

Where $U$ is the potential energy, $m$ is the mass of the object, $g$ is the acceleration due to gravity, and $h$ is the height above the reference point.

#### Momentum

Momentum, often denoted by $p$, is a vector quantity that is the product of the mass and velocity of an object. It is a measure of the motion of the object. The momentum of an object of mass $m$ moving with a velocity $v$ is given by the equation:

$$
p = m \times v
$$

Where $p$ is the momentum, $m$ is the mass of the object, and $v$ is its velocity.

The law of conservation of momentum states that the total momentum of a closed system of objects (i.e., a system on which no external forces are acting) is constant.

#### Systems of Particles

In a system of particles, the total energy is the sum of the kinetic and potential energies of all the particles, and the total momentum is the vector sum of the momenta of all the particles.

The kinetic energy of a system of $N$ particles, each of mass $m_i$ and velocity $v_i$, is given by:

$$
K = \frac{1}{2} \sum_{i=1}^{N} m_i v_i^2
$$

The momentum of a system of $N$ particles, each of mass $m_i$ and velocity $v_i$, is given by:

$$
p = \sum_{i=1}^{N} m_i v_i
$$

In the next section, we will explore how these concepts of energy and momentum apply to the study of statics and dynamics in unified engineering.

#### Work and Energy

Work, often denoted by $W$, is a measure of energy transfer that occurs when an object is moved by an external force along a displacement. It is calculated as the product of the force $F$ applied along the displacement and the displacement $d$ itself, and is given by the equation:

$$
W = F \times d
$$

Where $W$ is the work done, $F$ is the force applied, and $d$ is the displacement of the object.

The work done on an object is equal to the change in its kinetic energy, a principle known as the work-energy theorem. This can be mathematically represented as:

$$
W = \Delta K
$$

Where $\Delta K$ is the change in kinetic energy of the object.

In the context of engineering systems, work and energy principles can be applied to analyze and design various systems. For instance, in an electric stove, the electrical energy (work done by the electric field) is converted into thermal energy to heat the element. The typical electricity consumption of one heating element depending on size is 1–3 kW, which is the rate at which work is done or energy is transferred.

In another example, the Circle L engine 4EE2 produces work at a rate (power) of 4400 rpm and 1800 rpm. This work is then converted into kinetic energy to move the vehicle.

In renewable energy systems, such as solar augmented geothermal energy projects, work and energy principles are used to convert solar and geothermal energy into usable electrical energy. The energy conversion process involves work done by various forces, including gravitational forces and electromagnetic forces.

In all these systems, the law of conservation of energy holds, which states that the total energy of the system (including all forms of energy such as kinetic, potential, thermal, etc.) remains constant if no external work is done on the system.

In the next section, we will explore the concept of momentum and its conservation in engineering systems.

### Conclusion

In this chapter, we have explored the fundamental principles of Statics and Dynamics, two critical branches of Unified Engineering. We have delved into the concepts of forces, moments, equilibrium, and the laws of motion, which form the basis of these disciplines. 

Statics, the study of forces in equilibrium, has provided us with a deep understanding of how structures maintain their stability. We have learned how to calculate the forces acting on a body at rest and how to ensure that a structure is in equilibrium. 

On the other hand, Dynamics has allowed us to analyze the forces and motions of bodies in motion. We have studied Newton's laws of motion, which are the foundation of Dynamics, and learned how to apply them to various engineering problems. 

By understanding Statics and Dynamics, we can design and analyze structures and machines more effectively and safely. These principles are not only applicable to mechanical and civil engineering but also to other fields such as aerospace and biomedical engineering. 

In conclusion, the knowledge and skills acquired in this chapter are fundamental to the practice of Unified Engineering. They provide the basis for understanding and solving complex engineering problems.

### Exercises

#### Exercise 1
Calculate the forces acting on a beam supported at two points, with a uniformly distributed load. Use the principles of statics to ensure the beam is in equilibrium.

#### Exercise 2
A car of mass $m$ is moving with a velocity $v$. Calculate the kinetic energy of the car using the principles of dynamics.

#### Exercise 3
A body is in equilibrium under the action of three forces. Two of the forces are known. Determine the third force.

#### Exercise 4
A projectile is launched with an initial velocity $v_0$ at an angle $\theta$ to the horizontal. Determine the maximum height reached by the projectile and the range.

#### Exercise 5
A block of mass $m$ is sliding down a frictionless inclined plane of angle $\theta$. Determine the acceleration of the block and the normal force acting on it.

## Chapter 3: Materials Science

### Introduction

Welcome to Chapter 3: Materials Science, a crucial component of our Comprehensive Guide to Unified Engineering. This chapter will delve into the fascinating world of materials science, a discipline that merges concepts from physics, chemistry, and engineering to understand the properties of materials, and how changes in these properties can affect their performance.

Materials science is a broad field, and its principles are applied in numerous areas of engineering. From the design of aircraft and automobiles to the development of biomedical devices and renewable energy technologies, the understanding of materials and their properties is fundamental. 

In this chapter, we will explore the basic principles of materials science, including the structure and properties of different types of materials. We will discuss how these properties can be manipulated through processes such as heat treatment or alloying, and how these changes can influence the performance of materials in various applications.

We will also delve into the role of materials science in solving some of the world's most pressing problems, such as energy efficiency and sustainability. Through this exploration, we hope to provide a comprehensive understanding of the importance of materials science in unified engineering.

Remember, materials science is not just about understanding the properties of materials, but also about using this knowledge to design and create better materials for the future. As we journey through this chapter, we hope to inspire you with the possibilities that materials science offers, and equip you with the knowledge to contribute to this exciting field. 

So, let's embark on this journey of discovery together, exploring the world of materials science and its pivotal role in unified engineering.

### Section: 3.1 Atomic Structure

The atomic structure is the foundation of materials science. It is the arrangement of subatomic particles—protons, neutrons, and electrons—that gives each element its unique properties. Understanding atomic structure is crucial for understanding the behavior of materials and how they can be manipulated for various applications in engineering.

#### 3.1.1 Basic Atomic Structure

An atom consists of a nucleus, which contains protons and neutrons, and an electron cloud, which is the region around the nucleus where electrons are most likely to be found. The number of protons in an atom's nucleus, known as the atomic number, determines the identity of the element. The number of neutrons and electrons can vary, leading to isotopes and ions, respectively.

Protons and neutrons are collectively referred to as nucleons, and their number in an atom's nucleus is known as the mass number. The mass number minus the atomic number gives the number of neutrons in an atom.

#### 3.1.2 Electron Configuration

Electrons in an atom are arranged in energy levels, or shells, around the nucleus. Each shell can hold a certain number of electrons, and the shells are filled from the lowest energy level to the highest. The arrangement of electrons in these shells is known as the electron configuration, and it plays a crucial role in determining an element's chemical properties.

The electron configuration is determined by the Pauli Exclusion Principle, which states that no two electrons in an atom can have the same set of quantum numbers. This principle leads to the Aufbau Principle, which states that electrons fill the lowest energy levels first, and Hund's Rule, which states that electrons will occupy empty orbitals in the same energy level before pairing up in the same orbital.

#### 3.1.3 Electronegativity

Electronegativity is a measure of an atom's ability to attract electrons in a chemical bond. It is a crucial concept in understanding the behavior of materials, as it influences the type of bonding that occurs between atoms and thus the properties of the resulting material.

The Pauling scale and the Allen scale are two commonly used scales to measure electronegativity. The Pauling scale is based on bond energies, while the Allen scale is based on the average energy of the valence electrons in a free atom.

#### 3.1.4 Group 3 Elements

Group 3 elements in the periodic table include scandium, yttrium, lutetium, and lawrencium. These elements have similar properties due to their similar electron configurations. The classification of these elements in Group 3 has been a subject of debate, but the International Union of Pure and Applied Chemistry (IUPAC) reaffirmed this classification in 2021[^1^].

Understanding the atomic structure and properties of elements is crucial for understanding the behavior of materials. In the following sections, we will delve deeper into the structure of materials and how their properties can be manipulated for various applications in engineering.

[^1^]: IUPAC, "Names and Symbols of the Elements with Atomic Numbers 113, 115, 117 and 118," Pure Appl. Chem., vol. 88, no. 12, pp. 1225–1229, 2016.

### Section: 3.2 Crystal Structure

The crystal structure of a material is the arrangement of atoms, ions, or molecules in a crystalline material or solid. It is a crucial aspect of materials science as it significantly influences the physical properties of a material, including hardness, ductility, electrical and thermal conductivity, and optical properties.

#### 3.2.1 Polymorphism

Polymorphism refers to the ability of a solid material to exist in more than one form or crystal structure. For example, zinc sulfide (ZnS) can exist in two forms: zincblende, which has a cubic crystal structure, and wurtzite, which has a hexagonal crystal structure. These are denoted as <chem2|ZnS("c")> and <chem2|ZnS("h")> respectively. Polymorphism can significantly affect the properties of a material, and understanding it is crucial for the design and application of materials in engineering.

#### 3.2.2 Unit Cell

The unit cell is the smallest repeating unit of a crystal structure that exhibits the full symmetry of the crystal. It is defined as a parallelepiped, characterized by six lattice parameters: the lengths of the cell edges ("a", "b", "c") and the angles between them (α, β, γ). The positions of particles within the unit cell are described by fractional coordinates ("x<sub>i</sub>", "y<sub>i</sub>", "z<sub>i</sub>") along the cell edges, measured from a reference point.

The unit cell is not just a physical space but also a representation of the symmetry of the crystal structure. All other particles of the unit cell are generated by the symmetry operations that characterize the symmetry of the unit cell. This collection of symmetry operations is formally expressed as the space group of the crystal structure.

#### 3.2.3 Miller Indices

Miller indices are a notation system used in crystallography for planes and directions in crystal lattices. In this system, a plane is denoted by three integers "h", "k", and "ℓ". These indices are inversely proportional to the intercepts of the plane with the unit cell. In other words, a plane with Miller indices (hkl) intercepts the three points "a"<sub>1</sub>/"h", "a"<sub>2</sub>/"k", and "a"<sub>3</sub>/"ℓ", or some multiple thereof.

Understanding and being able to calculate Miller indices is crucial for describing crystal structures and their properties. For example, the orientation of a crystal plane can significantly affect its reactivity or how it interacts with light.

In the next section, we will delve deeper into the different types of crystal structures and how they are determined by the arrangement and bonding of atoms.

### Section: 3.3 Mechanical Properties

The mechanical properties of materials are crucial in determining their suitability for specific applications in engineering. These properties describe the behavior of materials under different types of loads and conditions. They include elasticity, plasticity, tensile strength, compressive strength, shear strength, fracture toughness, ductility, and hardness.

#### 3.3.1 Elasticity

Elasticity is the ability of a material to return to its original shape after being deformed by an external force. It is quantified by the elastic modulus, also known as Young's modulus ($E$), which is the ratio of stress ($\sigma$) to strain ($\varepsilon$) in the linear elastic region of a material's stress-strain curve:

$$
E = \frac{\sigma}{\varepsilon}
$$

Materials with a high elastic modulus, such as steel and tungsten carbide, are stiffer and less deformable under stress.

#### 3.3.2 Plasticity

Plasticity is the ability of a material to permanently deform without breaking when subjected to stress beyond its yield strength. This property is crucial in applications where materials need to be shaped or formed, such as in metal forging or plastic injection molding.

#### 3.3.3 Tensile Strength

Tensile strength is the maximum stress a material can withstand while being stretched or pulled before breaking. It is a critical property for materials used in applications where tensile loads are prevalent, such as in the construction of bridges or aircraft.

#### 3.3.4 Compressive Strength

Compressive strength is the capacity of a material to withstand loads that tend to reduce size. It is an essential property for materials used in structures that bear heavy loads, such as concrete in buildings and bridges.

#### 3.3.5 Shear Strength

Shear strength is the maximum shear stress a material can withstand before it begins to deform plastically. This property is important for materials used in applications where shear loads are common, such as in the shafts of rotating machinery.

#### 3.3.6 Fracture Toughness

Fracture toughness is a measure of a material's resistance to fracture when a crack is present. It is particularly important in applications where failure due to crack propagation could have catastrophic consequences, such as in aircraft structures or pressure vessels.

#### 3.3.7 Ductility

Ductility is the ability of a material to deform under tensile stress. Materials with high ductility, such as gold and copper, can be drawn into thin wires without breaking.

#### 3.3.8 Hardness

Hardness is the resistance of a material to localized deformation, particularly indentation or scratching. It is a critical property for materials used in wear-resistant applications, such as the cutting edges of tools or the surfaces of bearings.

Understanding these mechanical properties and how they are influenced by factors such as temperature, strain rate, and microstructure is fundamental to the design and selection of materials in engineering.

### Section: 3.4 Phase Diagrams

Phase diagrams are graphical representations that depict the equilibrium conditions between different phases of a material at various temperatures and pressures. They are essential tools in materials science and engineering, providing valuable information about the phase transitions, stability of phases, and the effects of temperature and pressure on the material's phase.

#### 3.4.1 Components and Phases

A phase is a region of material that has uniform physical and chemical properties. Each phase in a material is represented by a separate area in the phase diagram. The number of components in a system is represented by the number of independent chemical species present. For example, in a binary alloy system such as austenitic stainless steel, the components would be the constituent elements, typically iron and chromium.

#### 3.4.2 Phase Boundaries and Equilibrium

Phase boundaries, also known as phase lines, separate different phases on the diagram. The points where these lines meet are known as triple points, where three phases coexist in equilibrium. For instance, the critical point in the phase diagram of a pure substance is the temperature and pressure at which the substance's gas and liquid phases become indistinguishable.

#### 3.4.3 Binary Phase Diagrams

Binary phase diagrams represent systems with two components. They are typically represented with temperature on the vertical axis and the composition (usually in mole fraction or weight percent) on the horizontal axis. For example, the phase diagram of a magnesium/teflon/viton system would show the equilibrium phases at various temperatures and compositions.

#### 3.4.4 Interpretation of Phase Diagrams

Interpreting phase diagrams involves understanding the phase or phases present at a given temperature and composition, the composition of each phase, and the amount of each phase. For example, in the phase diagram of an iron-carbon alloy (steel), the phase diagram can indicate whether the material will have a body-centered cubic (bcc) structure (ferrite phase) or a face-centered cubic (fcc) structure (austenite phase) at a given temperature and carbon concentration.

Phase diagrams are crucial in materials engineering as they provide a roadmap for controlling the microstructure of a material, and hence, its properties. By understanding and utilizing phase diagrams, engineers can predict how a material will behave under specific conditions and design materials with desired properties for various applications.

### Section: 3.5 Material Testing

Material testing is a critical aspect of materials science, used to assess the quality, functionality, safety, reliability, and toxicity of both materials and electronic devices. It is applied in various fields, including defect detection, failure analysis, material development, basic materials science research, and the verification of material properties for application trials.

#### 3.5.1 Types of Material Testing

There are several types of material testing, each designed to evaluate specific properties of a material. These include:

- **Mechanical Testing**: This involves applying forces to a material and measuring its response. Common tests include tensile strength, compressive strength, and hardness tests.

- **Thermal Testing**: This assesses a material's response to changes in temperature. It includes tests for thermal conductivity, thermal expansion, and heat resistance.

- **Chemical Testing**: This involves determining the chemical composition of a material and its resistance to various chemicals.

- **Environmental Testing**: This assesses a material's durability and performance under different environmental conditions, such as humidity, UV radiation, and corrosive environments.

#### 3.5.2 Material Testing Standards

International organizations, such as ASTM International, ISO, and IEC, develop and publish standards for material testing. These standards ensure that tests are conducted in a consistent and reliable manner, enabling comparison of results across different laboratories and materials.

#### 3.5.3 Material Testing Laboratories

Global research laboratories offer material testing services, providing essential data for industries and researchers. These laboratories are equipped with advanced testing equipment and follow international standards to ensure the accuracy and reliability of their results.

#### 3.5.4 Material Testing of Common Materials

Common materials tested include carbon steel, stainless steel, chrome steel, brass, aluminium, tungsten carbide, platinum, gold, titanium, and plastic. These materials are used in a wide range of applications, and their properties need to be thoroughly understood to ensure their safe and effective use.

#### 3.5.5 Material Testing of Less Common Materials

Less common materials, such as copper, monel, k-monel, lead, silver, glass, and niobium, are also subject to material testing. These materials often have unique properties that make them suitable for specific applications, and understanding these properties is crucial for their effective use.

#### 3.5.6 Safety System Testing

Safety system testing is a critical aspect of material testing, ensuring that both surface and subsurface safety systems function as intended. This includes testing for interstitial defects, which can modify the physical and chemical properties of materials.

In the next section, we will delve deeper into the specific methods and techniques used in material testing, providing a comprehensive understanding of how these tests are conducted and interpreted.

### Section: 3.6 Failure Analysis

Failure analysis is an essential part of materials science, which involves the systematic investigation of a material or component failure. The goal is to understand the root cause of the failure to prevent future occurrences. This section will delve into the concept of elasticity, a fundamental property of materials that plays a significant role in failure analysis.

#### 3.6a Elasticity

Elasticity is the ability of a material to return to its original shape after being deformed by an external force. It is a measure of a material's resistance to deformation and is a critical factor in determining a material's suitability for specific applications.

The mathematical representation of elasticity is given by the elasticity tensor, denoted as $\mathbf{C}$. For an isotropic material, the elasticity tensor simplifies to:

$$
C^{ijkl} = \lambda \!\left( X \right) g^{ij} g^{kl} + \mu\!\left( X \right) \left(g^{ik} g^{jl} + g^{il} g^{kj} \right)
$$

where $\lambda$ and $\mu$ are scalar functions of the material coordinates $X$, and $\mathbf{g}$ is the metric tensor in the reference frame of the material. In an orthonormal Cartesian coordinate basis, there is no distinction between upper and lower indices, and the metric tensor can be replaced with the Kronecker delta:

$$
C_{ijkl} = \lambda \!\left( X \right) \delta_{ij} \delta_{kl} + \mu\!\left( X \right) \left(\delta_{ik} \delta_{jl} + \delta_{il} \delta_{kj} \right) \quad \text{[Cartesian coordinates]}
$$

Substituting the first equation into the stress-strain relation and summing over repeated indices gives the trace of $\mathbf{E}$, denoted as $\mathrm{Tr}\, \mathbf{E} \equiv E^i_{\,i}$. In this form, $\mu$ and $\lambda$ can be identified with the first and second Lamé parameters.

For cubic crystals, the elasticity tensor has components:

$$
C^{ijkl} = \lambda g^{ij} g^{kl} + \mu \left(g^{ik} g^{jl} + g^{il} g^{kj} \right) + \alpha \left(a^i a^j a^k a^l + b^i b^j b^k b^l + c^i c^j c^k c^l\right)
$$

where $\mathbf{a}$, $\mathbf{b}$, and $\mathbf{c}$ are unit vectors corresponding to the three mutually perpendicular axes of the crystal unit cell. The coefficients $\lambda$, $\mu$, and $\alpha$ are scalars.

Understanding the elasticity of materials is crucial in predicting their behavior under stress and strain, which is vital in failure analysis. In the following sections, we will explore how this property influences the failure modes of different materials.

#### 3.6b Plasticity

Plasticity, in contrast to elasticity, is the ability of a material to undergo permanent deformation without breaking or failing when subjected to external forces. This property is crucial in many engineering applications, such as in the design of ductile materials that can absorb energy during deformation, like in the crumple zones of cars.

The mathematical representation of plasticity is given by the plastic potential function, denoted as $f(\sigma, \varepsilon^p)$, where $\sigma$ is the stress tensor and $\varepsilon^p$ is the plastic strain tensor. The plastic potential function is used to determine the direction of plastic flow in the material. 

The plastic flow rule, which describes the evolution of plastic strain, can be written as:

$$
\dot{\varepsilon}^p = \dot{\lambda} \frac{\partial f}{\partial \sigma}
$$

where $\dot{\lambda}$ is the plastic multiplier, which is determined by the consistency condition $f(\sigma, \varepsilon^p) = 0$ for plastic loading and $f(\sigma, \varepsilon^p) \leq 0$ for elastic unloading.

The plasticity of a material is also influenced by the Hebbian plasticity theory, which is a learning rule that states that the synaptic weight between two neurons is increased when they are co-activated. This theory can be applied to materials science by considering the material's microstructure as a network of interconnected elements (e.g., grains in a polycrystalline material) that can "learn" and adapt to external loads, leading to plastic deformation.

The Hebbian plasticity rule can be mathematically represented as:

$$
\Delta w_{ij} = \eta x_i x_j
$$

where $w_{ij}$ is the synaptic weight between elements $i$ and $j$, $\eta$ is the learning rate, and $x_i$ and $x_j$ are the activities of elements $i$ and $j$, respectively. This rule implies that the synaptic weight (or the strength of the connection between elements) increases when the elements are co-activated, leading to plastic deformation.

In the context of materials science, this theory can be used to model the evolution of the material's microstructure under external loads, leading to a better understanding of the material's plastic behavior. This can be particularly useful in the design of materials with tailored mechanical properties, such as high strength and ductility.

#### 3.6c Creep and Fatigue

Creep and fatigue are two important failure mechanisms in materials science that are often encountered in engineering applications. 

Creep is the slow, time-dependent deformation of a material under a constant stress. It is particularly relevant in high-temperature applications, such as in the engines of cars or airplanes, where materials are subjected to prolonged periods of high stress and temperature. 

The creep strain, $\varepsilon_{cr}$, can be represented mathematically as:

$$
\varepsilon_{cr} = \varepsilon_0 + \frac{\sigma}{E}t + K\sigma^n t
$$

where $\varepsilon_0$ is the initial strain, $\sigma$ is the applied stress, $E$ is the modulus of elasticity, $t$ is the time, $K$ is the creep constant, and $n$ is the stress exponent. The first term represents the initial elastic deformation, the second term represents the primary or transient creep, and the third term represents the secondary or steady-state creep.

Fatigue, on the other hand, is the progressive and localized structural damage that occurs when a material is subjected to cyclic loading. The maximum stress values are less than the material's ultimate tensile stress limit, and as the cyclic loading continues, the damage accumulates, eventually leading to failure. This is often seen in rotating machinery, such as in the bearings of engines, where the material is subjected to repeated cycles of stress.

The number of cycles to failure, $N_f$, under a given stress amplitude, $\sigma_a$, can be represented by the Basquin's Law:

$$
\sigma_a = \sigma'_{f} (2N_f)^b
$$

where $\sigma'_{f}$ is the fatigue strength coefficient and $b$ is the fatigue strength exponent. 

Both creep and fatigue are influenced by the material's microstructure, and understanding these failure mechanisms is crucial in the design and selection of materials for engineering applications. For example, in the design of engines, materials that are resistant to creep and fatigue are preferred to ensure the longevity and reliability of the engine.

In the next section, we will discuss the methods used to analyze and predict these failure mechanisms, and how they can be mitigated through material selection and design.

#### 3.6d Composite Materials

Composite materials are a class of materials that are made up of two or more constituent materials with significantly different physical or chemical properties. These materials remain distinct within the finished structure, resulting in a material with characteristics different from the individual components. The individual components remain separate and distinct within the finished structure, maintaining their original properties and contributing to the overall composite properties.

Composite materials are generally used for buildings, bridges, and structures such as boat hulls, swimming pool panels, racing car bodies, shower stalls, bathtubs, storage tanks, imitation granite, and cultured marble sinks and countertops. The most advanced examples perform routinely on spacecraft and aircraft in demanding environments.

##### Failure Analysis of Composite Materials

The failure analysis of composite materials involves understanding the various modes of failure, which can be complex due to the anisotropic nature of these materials. The failure modes can include fiber breakage, matrix cracking, delamination, and fiber-matrix debonding. 

The failure of composite materials can be represented by the Tsai-Hill failure criterion:

$$
\frac{\sigma_x^2}{X^2} + \frac{\sigma_y^2}{Y^2} - \frac{\sigma_x \sigma_y}{X^2} + \frac{\tau_{xy}^2}{S^2} = 1
$$

where $\sigma_x$ and $\sigma_y$ are the stresses in the x and y directions, $\tau_{xy}$ is the shear stress, and $X$, $Y$, and $S$ are material properties.

##### 3D Composite Materials

Three-dimensional composites use fiber preforms constructed from yarns or tows arranged into complex three-dimensional structures. These can be created from a 3D weaving process, a 3D knitting process, a 3D braiding process, or a 3D lay of short fibers. A resin is applied to the 3D preform to create the composite material. 

Three-dimensional composites are used in highly engineered and highly technical applications in order to achieve complex mechanical properties. They are engineered to react to stresses and strains in ways that are not possible with traditional composite materials composed of single direction tows, or 2D woven composites, sandwich composites or stacked laminate materials.

##### 3D Woven Composites

Three-dimensional woven fabrics are fabrics that could be formed to near net shape with considerable thickness. There is no need for layering to create a part, because a single fabric provides the full three-dimensional reinforcement. The 3-D woven fabric is a variant of the 2D weaving process, and it is an extension of the very old technique of creating double and triple woven cloth. 3D weaving allows the production of fabrics up to 10 cm in thickness. Fibers placed in the thickness direction are called z-yarn, warp weaver, or binder yarn for 3D woven fabrics.

Understanding the properties and failure mechanisms of composite materials, particularly 3D composites, is crucial in the design and selection of materials for engineering applications. For example, in the design of aerospace structures, materials that are lightweight yet strong and resistant to various failure modes are preferred.

#### 3.6e Heat Treatment

Heat treatment is a controlled process used to alter the microstructure of materials, such as metals and alloys, to impart properties which benefit the working life of a component, such as increased surface hardness, temperature resistance, ductility, and strength. Heat treatment involves the use of heating or chilling, normally to extreme temperatures, to achieve a desired result such as hardening or softening of a material.

##### Failure Analysis of Heat Treated Materials

The failure analysis of heat-treated materials involves understanding the various modes of failure, which can be complex due to the changes in microstructure caused by the heat treatment process. The failure modes can include thermal fatigue, creep, stress rupture, and embrittlement.

The failure of heat-treated materials can be represented by the time-temperature-transformation (TTT) diagrams, which illustrate when transformations can occur in a material as a function of time at a specific temperature. 

$$
\frac{dT}{dt} = -k(T - T_{\infty})
$$

where $T$ is the temperature of the material, $T_{\infty}$ is the temperature of the environment, $k$ is the heat transfer coefficient, and $t$ is time.

##### Heat Treatment Processes

There are several types of heat treatment processes, including annealing, case hardening, precipitation strengthening, and tempering. 

- **Annealing** is a heat treatment process that alters the physical and sometimes chemical properties of a material to increase its ductility and reduce its hardness. This process involves heating a material to above its recrystallization temperature, maintaining a suitable temperature, and then cooling.

- **Case hardening** is a process of hardening the surface of a metal, often a low carbon steel, by infusing elements into the material's surface, forming a thin layer of a harder alloy.

- **Precipitation strengthening** (also called age hardening or particle hardening) is a heat treatment technique that enhances the yield strength of malleable materials, including most structural alloys of aluminium, magnesium, nickel, titanium, and some steels and stainless steels.

- **Tempering** is a process of heat treating, which is used to increase the toughness of iron-based alloys. Tempering is usually performed after hardening, to reduce some of the excess hardness, and is done by heating the metal to a much lower temperature than was used for hardening.

The specific process used depends on the material and the desired properties. The heat treatment process can significantly affect the performance of a material in service, and a thorough understanding of these processes is essential for predicting material behavior.

### Conclusion

In this chapter, we have delved into the fascinating world of Materials Science, a critical component of Unified Engineering. We have explored the fundamental principles that govern the behavior of materials, their properties, and how they interact with each other. We have also examined the role of materials science in the broader context of engineering, and how it contributes to the design, development, and optimization of various engineering systems.

We have seen that Materials Science is not just about understanding the properties of materials, but also about manipulating these properties to suit specific engineering needs. This involves a deep understanding of the structure of materials at various scales, from the atomic to the macroscopic, and how these structures influence the properties of the materials.

We have also discussed the importance of materials selection in engineering design, and how the choice of material can significantly impact the performance, efficiency, and sustainability of an engineering system. We have seen that this requires a careful balance of various factors, including the material's properties, cost, availability, and environmental impact.

In conclusion, Materials Science is a vital field that underpins all aspects of engineering. It provides the foundation for the design and development of new materials, and the optimization of existing ones, to meet the ever-evolving demands of engineering. As we move forward in this book, we will continue to explore the other components of Unified Engineering, building on the knowledge we have gained in this chapter.

### Exercises

#### Exercise 1
Discuss the role of atomic structure in determining the properties of a material. How can manipulating the atomic structure change these properties?

#### Exercise 2
Choose an engineering system of your choice and discuss the materials used in its construction. Why were these materials chosen? What properties do they have that make them suitable for this application?

#### Exercise 3
Discuss the concept of materials selection in engineering design. What factors need to be considered when choosing a material for a particular application?

#### Exercise 4
Choose a material and discuss its properties at various scales, from the atomic to the macroscopic. How do these properties influence the behavior of the material?

#### Exercise 5
Discuss the environmental impact of materials selection in engineering design. How can engineers ensure that their choice of materials is sustainable?

## Chapter 4: Thermodynamics

### Introduction

Welcome to Chapter 4: Thermodynamics, a crucial component of our Comprehensive Guide to Unified Engineering. This chapter is designed to provide a broad overview of the fundamental principles of thermodynamics, a branch of physics that deals with the relationships between heat and other forms of energy.

Thermodynamics is a cornerstone of many engineering disciplines, including mechanical, chemical, and aerospace engineering. It is a field that describes how energy is transferred and transformed, and it provides the theoretical foundation for understanding phenomena such as heat transfer, energy conversion, and the performance of engines and refrigerators.

In this chapter, we will delve into the laws of thermodynamics, starting with the zeroth law, which introduces the concept of thermal equilibrium, and progressing through the first, second, and third laws, which deal with energy, entropy, and absolute zero, respectively. We will also explore concepts such as the thermodynamic system and its surroundings, the different types of thermodynamic processes, and the role of energy in these processes.

We will also discuss the practical applications of thermodynamics in engineering, such as the design and analysis of engines, refrigerators, and heat pumps. We will illustrate these applications with real-world examples and case studies, helping you to understand not only the theoretical principles but also their practical implications.

Remember, thermodynamics is not just about memorizing formulas and laws. It's about understanding the fundamental principles that govern the universe. So, as you read this chapter, try to grasp the underlying concepts and principles, and think about how they apply to the real world. This will not only help you to understand thermodynamics better, but it will also make you a better engineer.

So, let's dive into the fascinating world of thermodynamics!

### Section: 4.1 Laws of Thermodynamics

The laws of thermodynamics are fundamental principles that govern the behavior of energy in all its forms. These laws are universal and apply to all systems, regardless of their specific details. They provide a framework for understanding how energy is transferred and transformed, and they have profound implications for a wide range of phenomena, from the operation of engines and refrigerators to the behavior of black holes and the universe as a whole.

#### 4.1.1 Zeroth Law of Thermodynamics

The Zeroth Law of Thermodynamics introduces the concept of thermal equilibrium. It states that if two systems are each in thermal equilibrium with a third system, then they are in thermal equilibrium with each other. This law allows us to define temperature in a consistent and meaningful way. In essence, it provides a basis for the concept of temperature and establishes that temperature is a fundamental and measurable property of matter.

#### 4.1.2 First Law of Thermodynamics

The First Law of Thermodynamics, also known as the Law of Energy Conservation, states that energy cannot be created or destroyed, only transferred or transformed. In mathematical terms, this can be expressed as:

$$
\Delta U = Q - W
$$

where $\Delta U$ is the change in internal energy of the system, $Q$ is the heat added to the system, and $W$ is the work done by the system. This law is a statement of the conservation of energy principle and it provides a method to calculate the change in internal energy of a system as it undergoes a process.

#### 4.1.3 Second Law of Thermodynamics

The Second Law of Thermodynamics introduces the concept of entropy, a measure of the disorder or randomness of a system. It states that in any energy transfer or transformation, the total entropy of a system and its surroundings always increases over time. This law provides a direction to the process and it is often associated with the concept of irreversibility. It can be mathematically expressed as:

$$
\Delta S \geq \frac{Q_{rev}}{T}
$$

where $\Delta S$ is the change in entropy, $Q_{rev}$ is the heat transferred reversibly, and $T$ is the absolute temperature.

#### 4.1.4 Third Law of Thermodynamics

The Third Law of Thermodynamics states that the entropy of a perfect crystal at absolute zero temperature is zero. This law provides a reference point for the determination of entropy at any other temperature. It also implies that it is impossible to reach absolute zero temperature by any finite number of processes.

In the following sections, we will delve deeper into each of these laws, exploring their implications and applications in various fields of engineering. We will also discuss the equations related to these laws, such as the general equation of heat transfer and the equation for entropy production, and their relevance in practical scenarios.

### Section: 4.2 Heat and Work

In thermodynamics, heat and work are two primary ways that a system exchanges energy with its surroundings. Although they are both forms of energy transfer, they are fundamentally different in their physical nature.

#### 4.2.1 Heat

Heat is a form of energy transfer that occurs due to a temperature difference between a system and its surroundings. It is a spontaneous process that flows from a region of higher temperature to a region of lower temperature. The amount of heat transferred, $Q$, can be calculated using the equation:

$$
Q = mc\Delta T
$$

where $m$ is the mass of the substance, $c$ is the specific heat capacity of the substance, and $\Delta T$ is the change in temperature.

Heat transfer can occur through three main mechanisms: conduction, convection, and radiation. Conduction is the transfer of heat through direct contact of particles, convection is the transfer of heat through the movement of fluid, and radiation is the transfer of heat through electromagnetic waves.

#### 4.2.2 Work

Work, on the other hand, is a form of energy transfer that occurs when a force is applied to an object and the object moves in the direction of the force. The amount of work done, $W$, can be calculated using the equation:

$$
W = Fd
$$

where $F$ is the force applied and $d$ is the distance moved in the direction of the force.

In the context of thermodynamics, work can be done by a system (such as when a gas expands against the surroundings) or on a system (such as when the surroundings compress a gas). The sign convention typically used in thermodynamics is that work done by the system is positive, and work done on the system is negative.

#### 4.2.3 Relationship between Heat and Work

The First Law of Thermodynamics establishes a relationship between heat, work, and the internal energy of a system. It states that the change in internal energy of a system is equal to the heat added to the system minus the work done by the system:

$$
\Delta U = Q - W
$$

This equation shows that heat and work are interchangeable forms of energy. It also implies that energy can be transferred between a system and its surroundings through heat and work.

In the next section, we will explore the concept of entropy and its role in thermodynamics.

### Section: 4.3 Energy Conversion

Energy conversion, in the context of thermodynamics, refers to the process of changing one form of energy into another. This is a fundamental concept in engineering, as many systems and devices are designed to convert energy from a form that is difficult to use to a form that is more useful. 

#### 4.3.1 Types of Energy Conversion

There are many types of energy conversion, but some of the most common in engineering include:

- **Mechanical to Electrical:** This is the type of energy conversion that occurs in a generator. Mechanical energy, in the form of rotational motion, is converted into electrical energy.

- **Chemical to Thermal:** This is the type of energy conversion that occurs in a combustion reaction, such as the burning of gasoline in a car engine. Chemical energy, stored in the bonds of the fuel, is released as thermal energy.

- **Thermal to Mechanical:** This is the type of energy conversion that occurs in a steam turbine. Thermal energy, in the form of high-temperature and high-pressure steam, is converted into mechanical energy as the steam expands and drives the turbine.

- **Electrical to Thermal:** This is the type of energy conversion that occurs in an electric stove or a space heater. Electrical energy is converted into thermal energy, which is then used to heat a room or cook food.

#### 4.3.2 Energy Conversion Efficiency

Not all energy conversions are 100% efficient. In fact, most are not. The efficiency of an energy conversion process is defined as the ratio of the useful output energy (or power) to the input energy (or power), and it is usually expressed as a percentage. The efficiency can be calculated using the equation:

$$
\eta = \frac{E_{out}}{E_{in}} \times 100\%
$$

where $\eta$ is the efficiency, $E_{out}$ is the output energy, and $E_{in}$ is the input energy.

For example, the efficiency of a typical gasoline engine is about 25%, which means that only about a quarter of the chemical energy in the gasoline is converted into useful mechanical energy. The rest is lost as waste heat.

#### 4.3.3 Energy Conversion in Combined Heat and Power Systems

Combined heat and power (CHP) systems, also known as cogeneration, are a type of energy conversion system that simultaneously produces electricity and useful heat from the same energy source. This is achieved by capturing and utilizing the waste heat that would otherwise be lost in a conventional power generation process.

Micro-CHP systems are smaller versions of CHP systems that are designed for residential or small commercial applications. They typically use a gas engine or a Stirling engine to generate electricity, and the waste heat from the engine is used to provide space heating and hot water.

Research has shown that micro-CHP systems can be more efficient and environmentally friendly than conventional power generation and heating systems. For example, a field trial performed in the UK found that micro-CHP systems resulted in average carbon savings of 9% for houses with heat demand over 54 GJ/year. Another study conducted by Oregon State University found that a state-of-the-art micro-CHP system operated at an electrical efficiency of 23.4% and a total efficiency of 74.4%.

In conclusion, energy conversion is a key concept in thermodynamics and engineering. By understanding the principles of energy conversion and the efficiency of different energy conversion processes, engineers can design systems and devices that make more efficient use of energy, thereby reducing energy consumption and environmental impact.

### Section: 4.4 Properties of Substances

The properties of substances are crucial in understanding and applying thermodynamics in engineering. These properties include physical and chemical characteristics that determine how substances interact with each other and how they respond to changes in their environment. 

#### 4.4.1 General Properties

The general properties of substances include their physical and chemical properties. Physical properties are those that can be observed or measured without changing the composition of the substance. These include color, odor, density, melting point, boiling point, and specific heat capacity. 

Chemical properties, on the other hand, describe how substances react with other substances. These include reactivity, flammability, and oxidation states. 

#### 4.4.2 Properties of Metals, Metalloids, and Nonmetals

Metals, metalloids, and nonmetals each have distinct properties that define their behavior in thermodynamic systems. 

**Metals** are good conductors of heat and electricity, are malleable and ductile, and have a lustrous appearance. They tend to lose electrons in chemical reactions, making them good reducing agents. 

**Nonmetals** are poor conductors of heat and electricity, are not malleable or ductile, and do not have a lustrous appearance. They tend to gain electrons in chemical reactions, making them good oxidizing agents. 

**Metalloids**, or semimetals, have properties intermediate between metals and nonmetals. They can act as electrical semiconductors, which makes them crucial in the electronics industry.

#### 4.4.3 Anomalous Properties

Some substances exhibit properties that are different from the norm within their category. These anomalies can be due to various factors, such as the presence of impurities, extreme pressure or temperature conditions, or quantum mechanical effects. Understanding these anomalous properties can often lead to new technological applications.

#### 4.4.4 Properties Under Different States of Matter

The properties of substances can change dramatically under different states of matter. For example, the density of a substance is typically much higher in the solid state than in the liquid or gas state. Similarly, the heat capacity of a substance can also vary with its state of matter. Understanding these changes is crucial for designing and analyzing thermodynamic systems.

#### 4.4.5 Properties of Emitted Substances

In thermodynamic systems, substances are often emitted as gases, liquid droplets, or particulate matter. The properties of these emitted substances, such as their chemical composition, temperature, and pressure, can significantly affect the performance and efficiency of the system. Therefore, it is important to accurately measure and control these properties in engineering applications.

### Section: 4.5 Thermodynamic Processes

Thermodynamic processes are the pathways by which a system changes from one state to another. These processes are characterized by changes in the thermodynamic variables of the system, such as pressure, volume, temperature, and entropy. 

#### 4.5.1 Types of Thermodynamic Processes

There are several types of thermodynamic processes, each defined by the variable that remains constant during the process:

- **Isothermal Process**: An isothermal process occurs when the temperature of the system remains constant. This is achieved by ensuring that the system is in thermal equilibrium with its surroundings. The general equation for an isothermal process is given by the ideal gas law, $PV = nRT$, where $P$ is the pressure, $V$ is the volume, $n$ is the number of moles of gas, $R$ is the gas constant, and $T$ is the temperature.

- **Isobaric Process**: An isobaric process occurs when the pressure of the system remains constant. This can be achieved by carrying out the process in a container with a movable piston, allowing the volume to change while maintaining constant pressure. The work done during an isobaric process is given by $W = P\Delta V$, where $\Delta V$ is the change in volume.

- **Adiabatic Process**: An adiabatic process is one in which no heat exchange occurs with the surroundings. This can be achieved by insulating the system from its surroundings. The equation for an adiabatic process for an ideal gas is given by $PV^\gamma = \text{constant}$, where $\gamma$ is the heat capacity ratio.

#### 4.5.2 Thermodynamic Cycles

A thermodynamic cycle is a sequence of thermodynamic processes that returns a system to its initial state. The net work done by the system during a cycle is equal to the net heat added to the system. The most common example of a thermodynamic cycle is the Carnot cycle, which consists of two isothermal processes and two adiabatic processes.

#### 4.5.3 Entropy and Thermodynamic Processes

Entropy is a fundamental concept in thermodynamics, representing the degree of disorder or randomness in a system. In any spontaneous process, the total entropy of a system and its surroundings always increases. This is known as the second law of thermodynamics.

The equation for entropy production is given by:

$$
\rho T \frac{Ds}{Dt} = \nabla\cdot(\kappa\nabla T) + \frac{\mu}{2}\left( \frac{\partial v_{i}}{\partial x_{j}} + \frac{\partial v_{j}}{\partial x_{i}} - \frac{2}{3}\delta_{ij}\nabla\cdot {\bf v} \right)^{2} + \zeta(\nabla \cdot {\bf v})^{2}
$$

where $\rho$ is the density, $T$ is the temperature, $s$ is the entropy, $\kappa$ is the thermal conductivity, $\mu$ is the dynamic viscosity, $v_i$ and $v_j$ are the components of the velocity vector, $x_i$ and $x_j$ are the spatial coordinates, $\delta_{ij}$ is the Kronecker delta, and $\zeta$ is the bulk viscosity.

Understanding these thermodynamic processes and their associated equations is crucial for the analysis and design of engineering systems, from power generation and refrigeration systems to chemical reactors and electronic devices.

### Section: 4.6 Power Cycles

Power cycles are the series of processes that a working fluid undergoes to convert heat into work and then dispose of the remaining heat. They are fundamental to the operation of heat engines, refrigerators, and heat pumps. The performance of these devices is often evaluated based on the efficiency of their power cycles.

#### 4.6.1 Heat Engines

Heat engines operate on a cycle and receive heat from a high-temperature reservoir. The engine does work on the surroundings while losing some heat to a low-temperature reservoir during the cycle. The most common example of a heat engine is the internal combustion engine, such as the 4EE2 engine, which produces power at 4400 rpm and torque at 1800 rpm.

The efficiency of a heat engine is defined as the ratio of the work done by the engine to the heat input at the high temperature, which can be expressed as:

$$
\eta = \frac{W}{Q_H}
$$

where $\eta$ is the efficiency, $W$ is the work done by the engine, and $Q_H$ is the heat input.

#### 4.6.2 Refrigerators and Heat Pumps

Refrigerators and heat pumps operate on a cycle and receive work from the surroundings. They transfer heat from a low-temperature reservoir to a high-temperature reservoir. The performance of these devices is often evaluated based on their coefficient of performance (COP), which is the ratio of the heat transfer at the high temperature to the work input, given by:

$$
COP = \frac{Q_H}{W}
$$

where $COP$ is the coefficient of performance, $Q_H$ is the heat transfer at the high temperature, and $W$ is the work input.

#### 4.6.3 Carnot Cycle

The Carnot cycle is an idealized power cycle that provides the upper limit on the efficiency that any classical thermodynamic engine can achieve during the conversion of heat into work, or conversely, the efficiency of a refrigeration system in creating a temperature difference by doing work. It consists of two isothermal processes and two adiabatic processes.

#### 4.6a Gas Laws

Gas laws are physical laws that describe the behavior of gases. They are based on the ideal gas model and include the Boyle's law, Charles's law, and Avogadro's law. The ideal gas law, which is a combination of these laws, states that the pressure multiplied by the volume of a gas is directly proportional to the number of moles of the gas and the absolute temperature, given by:

$$
PV = nRT
$$

where $P$ is the pressure, $V$ is the volume, $n$ is the number of moles of gas, $R$ is the gas constant, and $T$ is the absolute temperature.

In the context of power cycles, the ideal gas law is used to analyze the processes involving gases, such as the combustion process in an internal combustion engine. For example, the Reid vapor pressure of gasoline, which is 620 hPa (9.0 psi) at a temperature of 24 °C (75 °F), can be calculated using the ideal gas law.

### Section: 4.6b Thermodynamic Equilibrium

Thermodynamic equilibrium is a state of a system in which all macroscopic properties are unchanging in time. This state is achieved when the system is in thermal, mechanical, and chemical equilibrium. In the context of power cycles, thermodynamic equilibrium is crucial for the system to operate efficiently and predictably.

#### 4.6b.1 Thermal Equilibrium

Thermal equilibrium is achieved when the temperature within a system is uniform. When two systems are in thermal contact, they will eventually reach a common temperature. For example, in a heat engine, the working fluid will reach thermal equilibrium with the high-temperature reservoir before it begins to do work.

#### 4.6b.2 Mechanical Equilibrium

Mechanical equilibrium is achieved when there is no net force acting on any part of the system. This means that the pressure is uniform throughout the system. In the context of power cycles, this is important for maintaining the stability of the system and preventing mechanical failure.

#### 4.6b.3 Chemical Equilibrium

Chemical equilibrium is achieved when the rate of forward reaction equals the rate of the reverse reaction, resulting in no net change in the concentrations of reactants and products. This concept is particularly relevant in power cycles involving combustion, such as the internal combustion engine.

The state of chemical equilibrium can be described using the Gibbs free energy "G". At equilibrium, at a specified temperature and pressure, and with no external forces, the Gibbs free energy is at a minimum. This can be expressed as:

$$
G = \sum_j \mu_j N_j
$$

where $\mu_j$ is the chemical potential of molecular species "j", and $N_j$ is the amount of molecular species "j". 

For a closed system, the total number of atoms of each element will remain constant. This leads to a set of constraints:

$$
\sum_j a_{ij} N_j = b_i
$$

where $a_{ij}$ is the number of atoms of element "i" in molecule "j" and $b_i$ is the total number of atoms of element "i". 

This is a standard problem in optimisation, known as constrained minimisation. The most common method of solving it is using the method of Lagrange multipliers. The equilibrium condition is given by:

$$
\mu_j = \mu_j^{\ominus} + RT \ln A_j + \sum_i \lambda_i a_{ij}
$$

where $\mu_j^{\ominus}$ is the chemical potential in the standard state, "R" is the gas constant, "T" is the absolute temperature, "A_j" is the activity, and $\lambda_i$ are the Lagrange multipliers.

Understanding and applying the principles of thermodynamic equilibrium is crucial for the design and operation of efficient power cycles.

### Section: 4.6c Entropy and Entropy Generation

Entropy, represented by the symbol $S$, is a fundamental concept in thermodynamics. It is a measure of the randomness or disorder of a system. In the context of power cycles, entropy is crucial in understanding the efficiency and irreversibility of these cycles.

#### 4.6c.1 Entropy in Power Cycles

In power cycles, the concept of entropy is used to determine the maximum possible efficiency of a cycle. The second law of thermodynamics states that the total entropy of an isolated system can never decrease over time, and is constant if and only if all processes are reversible. This is known as the principle of increase of entropy.

In a power cycle, the working fluid undergoes a series of processes. The entropy change for a process from state 1 to state 2 is given by:

$$
\Delta S = \int_{1}^{2} \frac{dQ}{T}
$$

where $dQ$ is the differential heat transfer and $T$ is the absolute temperature. For a cycle, the total entropy change is zero.

#### 4.6c.2 Entropy Generation

Entropy generation or production refers to the increase in entropy in a system due to irreversibilities, such as friction, heat transfer, and chemical reactions. The entropy generation for a process from state 1 to state 2 is given by:

$$
S_{gen} = \int_{1}^{2} \frac{dQ_{irr}}{T}
$$

where $dQ_{irr}$ is the differential heat transfer due to irreversibilities.

The entropy generation is always greater than or equal to zero, according to the second law of thermodynamics. For a reversible process, the entropy generation is zero, and for an irreversible process, the entropy generation is greater than zero.

The concept of entropy generation is particularly important in power cycles, as it provides a measure of the irreversibility of the cycle. The greater the entropy generation, the less efficient the cycle is.

#### 4.6c.3 Entropy and the Carnot Cycle

The Carnot cycle is an idealized power cycle that operates between two thermal reservoirs at constant temperatures $T_H$ and $T_C$. The Carnot cycle is composed of two isothermal processes and two adiabatic processes, and is reversible.

The efficiency of the Carnot cycle is given by:

$$
\eta = 1 - \frac{T_C}{T_H}
$$

This efficiency is the maximum possible efficiency for a power cycle operating between the two temperatures $T_H$ and $T_C$. The Carnot cycle is an ideal standard for comparison of real power cycles.

In the Carnot cycle, the entropy change for each process is zero, and the total entropy change for the cycle is also zero. This is consistent with the principle of increase of entropy. The Carnot cycle is an idealization, and real power cycles have entropy generation due to irreversibilities.

### Section: 4.6d Heat Transfer

Heat transfer is a fundamental concept in thermodynamics and plays a crucial role in power cycles. It is the process by which thermal energy is exchanged between physical systems, depending on the temperature and pressure, by dissipating heat. The three fundamental modes of heat transfer are conduction, convection, and radiation.

#### 4.6d.1 Heat Transfer in Power Cycles

In power cycles, heat transfer occurs during the processes where the working fluid exchanges heat with the surroundings. The heat transfer for a process from state 1 to state 2 is given by:

$$
Q_{12} = \int_{1}^{2} TdS
$$

where $T$ is the absolute temperature and $dS$ is the differential entropy. The sign of $Q_{12}$ indicates the direction of the heat transfer. If $Q_{12}$ is positive, heat is transferred into the system (heat addition). If $Q_{12}$ is negative, heat is transferred out of the system (heat rejection).

#### 4.6d.2 Heat Transfer and Entropy Generation

Heat transfer is a source of entropy generation. As heat is transferred irreversibly from a high-temperature region to a low-temperature region, entropy is generated. This is due to the second law of thermodynamics, which states that processes occur in the direction of increasing entropy.

The entropy generation due to heat transfer is given by:

$$
S_{gen} = \int_{1}^{2} \frac{dQ_{irr}}{T}
$$

where $dQ_{irr}$ is the differential heat transfer due to irreversibilities. The entropy generation is always greater than or equal to zero, according to the second law of thermodynamics.

#### 4.6d.3 Heat Transfer and Efficiency

The efficiency of a power cycle is directly affected by the heat transfer processes. The more efficient the heat transfer, the higher the efficiency of the power cycle. However, due to irreversibilities such as friction and heat leakage, some of the heat transfer is always wasted, leading to entropy generation and a decrease in efficiency.

In the Carnot cycle, the heat transfer processes are reversible, so there is no entropy generation, and the cycle is as efficient as possible. However, in real power cycles, the heat transfer processes are not completely reversible, leading to entropy generation and a decrease in efficiency.

In the next section, we will discuss the different types of power cycles and how heat transfer and entropy generation affect their performance.

### Section: 4.6e Refrigeration and Air Conditioning

Refrigeration and air conditioning are essential applications of thermodynamics that involve power cycles. These systems operate on the principles of heat transfer and phase changes to provide cooling and temperature control.

#### 4.6e.1 Refrigeration Cycles

Refrigeration cycles are thermodynamic cycles that remove heat from a low-temperature region and discharge it at a higher temperature. The most common type of refrigeration cycle is the vapor-compression refrigeration cycle, which consists of four main components: the compressor, the condenser, the expansion valve, and the evaporator.

The cycle begins with the refrigerant entering the compressor as a low-pressure, low-temperature vapor. The compressor increases the pressure and temperature of the refrigerant, turning it into a high-pressure, high-temperature vapor. This hot vapor then enters the condenser, where it releases heat to the surroundings and condenses into a high-pressure liquid. The high-pressure liquid refrigerant then passes through the expansion valve, where its pressure and temperature drop suddenly. The low-pressure, low-temperature liquid refrigerant enters the evaporator, where it absorbs heat from the space to be cooled and evaporates back into a low-pressure vapor. The cycle then repeats.

#### 4.6e.2 Air Conditioning Cycles

Air conditioning cycles are similar to refrigeration cycles, but they also include processes to control the humidity, cleanliness, and distribution of the air. The most common type of air conditioning cycle is the vapor-compression cycle, which is similar to the refrigeration cycle described above.

In addition to the basic components of the refrigeration cycle, air conditioning systems often include a filter to remove dust and other particles from the air, a fan to distribute the cooled air, and a dehumidifier to control the humidity of the air.

#### 4.6e.3 Energy Efficiency in Refrigeration and Air Conditioning

Energy efficiency is a critical aspect of refrigeration and air conditioning systems. The efficiency of these systems is often measured by the coefficient of performance (COP), which is the ratio of the cooling effect to the work input:

$$
COP = \frac{Q_{cooling}}{W_{input}}
$$

where $Q_{cooling}$ is the heat removed from the cooled space and $W_{input}$ is the work input to the compressor. The higher the COP, the more efficient the system.

Improvements in energy efficiency can be achieved through various means, such as regular maintenance, proper insulation, and the use of energy-efficient components and technologies. For example, the introduction of new energy efficiency standards has led to significant improvements in the energy efficiency of refrigerators and air conditioners.

#### 4.6e.4 Environmental Impact of Refrigeration and Air Conditioning

Refrigeration and air conditioning systems can have significant environmental impacts, primarily due to the use of refrigerants that contribute to global warming and ozone depletion. The transition to more environmentally friendly refrigerants is a key challenge in the field of refrigeration and air conditioning.

### Conclusion

In this chapter, we have delved into the fascinating world of thermodynamics, a fundamental branch of physics that deals with heat and temperature and their relation to energy and work. We have explored the four laws of thermodynamics, each of which plays a crucial role in understanding the natural universe and the principles that govern energy transfer.

We started with the zeroth law of thermodynamics, which introduced us to the concept of thermal equilibrium and laid the foundation for the definition of temperature. The first law, also known as the law of energy conservation, taught us that energy cannot be created or destroyed, only transformed. The second law, perhaps the most well-known, introduced us to the concept of entropy and the directionality of energy transfer. Finally, the third law gave us insights into the absolute zero of temperature and its unattainability.

We also discussed the concepts of heat engines, refrigerators, and heat pumps, and their practical applications in our daily lives. We learned about the Carnot cycle, the most efficient heat engine cycle, and its significance in the field of engineering.

In essence, thermodynamics is a powerful tool that allows us to understand and predict the behavior of systems at macroscopic levels. It is a cornerstone of many engineering disciplines, including mechanical, chemical, and electrical engineering. As we move forward, we will continue to see its applications and implications in various fields.

### Exercises

#### Exercise 1
Explain the four laws of thermodynamics in your own words.

#### Exercise 2
A heat engine operates between two reservoirs at temperatures of 800 K and 400 K. What is the maximum possible efficiency of this engine? Use the formula for Carnot efficiency: $$\eta = 1 - \frac{T_c}{T_h}$$

#### Exercise 3
Describe the working principle of a refrigerator. How does it relate to the second law of thermodynamics?

#### Exercise 4
A heat pump operates between two reservoirs at temperatures of 300 K and 250 K. Calculate the coefficient of performance (COP) of this heat pump when it is used for heating. Use the formula for COP of a heat pump: $$COP = \frac{T_h}{T_h - T_c}$$

#### Exercise 5
Discuss the practical applications of the Carnot cycle in the field of engineering.

## Chapter: Fluid Mechanics

### Introduction

Fluid Mechanics is a fundamental discipline in the field of Unified Engineering, bridging the gap between the physical world and engineering applications. It is a branch of physics that studies the behavior of fluids, both at rest and in motion, and the forces that act on them. This chapter, Chapter 5: Fluid Mechanics, aims to provide a comprehensive understanding of the principles and theories that govern fluid behavior and their practical applications in engineering.

The study of Fluid Mechanics is crucial in various fields of engineering, including but not limited to, civil, mechanical, chemical, and aeronautical engineering. It is the key to understanding and designing systems involving fluid flow such as pumps, turbines, pipelines, and even the aerodynamics of vehicles.

In this chapter, we will delve into the fundamental concepts of Fluid Mechanics, starting with the definition of a fluid and its properties. We will explore the principles of fluid statics, fluid dynamics, and the concept of viscosity. We will also discuss the governing equations of fluid flow, namely the continuity equation, the Navier-Stokes equations, and the Bernoulli's equation. These equations are the mathematical representations of the conservation laws of mass, momentum, and energy in fluid flow.

We will also touch upon the concept of dimensional analysis and similarity, which is a powerful tool in the study of Fluid Mechanics. It allows us to predict the behavior of a fluid system under different conditions without the need for detailed solutions of the governing equations.

This chapter will provide a solid foundation for understanding the complex phenomena associated with fluid flow. It will equip you with the necessary tools and knowledge to analyze and design systems involving fluid flow. Whether you are a student, a researcher, or a practicing engineer, this chapter will serve as a valuable resource in your journey through the fascinating world of Fluid Mechanics.

Remember, Fluid Mechanics is not just about equations and theories. It is about understanding the world around us, from the flow of blood in our veins to the flow of air over an airplane wing. So, let's dive in and explore the wonderful world of Fluid Mechanics.

### Section: 5.1 Fluid Properties

In the study of fluid mechanics, understanding the properties of fluids is crucial. These properties define the behavior of fluids under different conditions and are essential in predicting how fluids will interact with various systems. In this section, we will discuss the key properties of fluids, including density, viscosity, vapor pressure, and relative permeability.

#### 5.1.1 Density

Density is a fundamental property of matter, including fluids. It is defined as the mass of a substance per unit volume. For a fluid with mass $m$ and volume $V$, the density $\rho$ is given by:

$$
\rho = \frac{m}{V}
$$

The SI unit for density is kilograms per cubic meter (kg/m<sup>3</sup>). The density of a fluid can change with temperature and pressure, but for liquids, this change is usually small.

#### 5.1.2 Viscosity

Viscosity is a measure of a fluid's resistance to shear or flow. It is often thought of as the "thickness" of a fluid. High viscosity fluids, like honey, resist flow more than low viscosity fluids, like water. The viscosity of a fluid can be affected by temperature, with most fluids becoming less viscous as they are heated.

#### 5.1.3 Vapor Pressure

Vapor pressure is the pressure exerted by a vapor in thermodynamic equilibrium with its condensed phases at a given temperature. It is a measure of the tendency of molecules to escape from the liquid or a solid. A substance with a high vapor pressure at normal temperatures is often referred to as volatile.

#### 5.1.4 Relative Permeability

Relative permeability is a dimensionless measure of the capability of a porous material to transmit a fluid under the presence of another fluid. It is a function of the saturation of the fluids and is typically represented by a curve. In multiphase systems, the relative permeability curves of each fluid phase are averaged.

Understanding these properties is fundamental to the study of fluid mechanics. They allow us to predict the behavior of fluids in various engineering applications, from the flow of oil in a pipeline to the aerodynamics of an airplane. In the following sections, we will delve deeper into these properties and explore their implications in fluid mechanics.

### Section: 5.2 Fluid Statics

Fluid statics, also known as hydrostatics, is the study of fluids at rest. The fundamental principle governing fluid statics is the concept of pressure and its variation with depth. This section will cover the basic principles of fluid statics, including the concepts of pressure, Pascal's law, and the hydrostatic equation.

#### 5.2.1 Pressure

Pressure is a scalar quantity defined as the force exerted per unit area. In the context of fluid statics, it is the force exerted by a fluid on the walls of its container or any object immersed in it. For a force $F$ acting on an area $A$, the pressure $P$ is given by:

$$
P = \frac{F}{A}
$$

The SI unit for pressure is the Pascal (Pa), which is equivalent to one Newton per square meter (N/m<sup>2</sup>). Pressure in a fluid at rest is the same in all directions, a consequence of the fluid's inability to sustain shear stress.

#### 5.2.2 Pascal's Law

Pascal's law, named after the French scientist Blaise Pascal, states that any change in pressure applied to an enclosed fluid is transmitted undiminished to all portions of the fluid and the walls of its container. Mathematically, if an incremental pressure $\Delta P$ is applied to a fluid, the change in pressure at any point in the fluid is also $\Delta P$.

#### 5.2.3 Hydrostatic Equation

The hydrostatic equation describes the variation of pressure with depth in a fluid at rest. It is derived from the balance of forces acting on a fluid element. The equation is given by:

$$
\frac{dP}{dz} = -\rho g
$$

where $P$ is the pressure, $z$ is the depth (measured positive upwards), $\rho$ is the fluid density, and $g$ is the acceleration due to gravity. The negative sign indicates that pressure increases with depth.

The hydrostatic equation is a fundamental tool in fluid statics, allowing us to calculate the pressure at any point in a fluid at rest given the fluid's density and the depth at that point.

In the next section, we will apply these principles to solve problems involving fluid statics, including calculating pressures and forces on submerged surfaces.

### Section: 5.3 Fluid Flow Kinematics

Fluid flow kinematics is the study of fluid motion without considering the forces or moments that cause the motion. This section will cover the basic principles of fluid flow kinematics, including the concepts of velocity field, streamlines, pathlines, streaklines, and the substantial derivative.

#### 5.3.1 Velocity Field

The velocity field of a fluid describes the fluid's velocity at every point in space at a given time. It is a vector field, represented by the vector $\mathbf{v}(\mathbf{x}, t)$, where $\mathbf{x}$ is the position vector and $t$ is the time. The velocity field provides a snapshot of the fluid's motion at a particular instant.

#### 5.3.2 Streamlines, Pathlines, and Streaklines

Streamlines, pathlines, and streaklines are three important concepts used to visualize fluid flow.

A streamline is a curve that is tangent to the velocity vector of the fluid at every point along the curve. Mathematically, a streamline satisfies the differential equation:

$$
\frac{d\mathbf{x}}{dt} = \mathbf{v}(\mathbf{x}, t)
$$

A pathline is the trajectory that a fluid particle follows. It is obtained by integrating the velocity field over time.

A streakline is the locus of particles that have passed through a particular spatial point in the past. It is the path traced by fluid particles that have passed through a specific point.

#### 5.3.3 Substantial Derivative

The substantial derivative, also known as the material derivative, is a derivative taken along a path moving with the fluid. It is used to describe the rate of change of a fluid property, such as velocity or temperature, as seen by an observer moving with the fluid. The substantial derivative of a scalar field $f(\mathbf{x}, t)$ is given by:

$$
\frac{Df}{Dt} = \frac{\partial f}{\partial t} + \mathbf{v} \cdot \nabla f
$$

where $\nabla f$ is the gradient of $f$.

In the next section, we will apply these principles to analyze fluid flow in various scenarios.

### Section: 5.4 Conservation Laws

Conservation laws are fundamental principles in physics that stem from the symmetry of space, time, and phase. These laws are crucial in the study of fluid mechanics as they provide the basis for understanding and predicting fluid behavior under various conditions. In this section, we will discuss the conservation laws of mass, momentum, and energy, and how they apply to fluid mechanics.

#### 5.4.1 Conservation of Mass

The conservation of mass, also known as the continuity equation, states that the mass of a system remains constant regardless of the processes acting inside the system. In fluid mechanics, this principle is applied to fluid flow to state that the mass flow rate entering a control volume is equal to the mass flow rate leaving it, assuming there is no change in the mass within the control volume.

Mathematically, the conservation of mass can be expressed as:

$$
\frac{\partial \rho}{\partial t} + \nabla \cdot (\rho \mathbf{v}) = 0
$$

where $\rho$ is the fluid density, $t$ is the time, $\mathbf{v}$ is the velocity field, and $\nabla \cdot (\rho \mathbf{v})$ is the divergence of the mass flux.

#### 5.4.2 Conservation of Momentum

The conservation of momentum is derived from Newton's second law of motion and states that the rate of change of momentum of a fluid particle is equal to the sum of the forces acting on it. In fluid mechanics, this principle is used to derive the Navier-Stokes equations, which describe the motion of fluid substances.

The conservation of momentum can be expressed as:

$$
\frac{D(\rho \mathbf{v})}{Dt} = -\nabla p + \mu \nabla^2 \mathbf{v} + \rho \mathbf{g}
$$

where $D/Dt$ is the substantial derivative, $p$ is the pressure, $\mu$ is the dynamic viscosity, $\nabla^2$ is the Laplacian operator, and $\mathbf{g}$ is the gravitational acceleration.

#### 5.4.3 Conservation of Energy

The conservation of energy, also known as the first law of thermodynamics, states that energy cannot be created or destroyed, only transferred or converted from one form to another. In fluid mechanics, this principle is used to analyze the energy transformations in fluid flow, including potential, kinetic, and internal energy.

The conservation of energy can be expressed as:

$$
\frac{D}{Dt} \left( \frac{1}{2} \rho v^2 + \rho e \right) = -\nabla \cdot (\rho \mathbf{v} h) + \rho \mathbf{v} \cdot \mathbf{g} + \Phi
$$

where $v$ is the speed of the fluid, $e$ is the internal energy per unit mass, $h$ is the enthalpy per unit mass, and $\Phi$ represents the work done by viscous forces.

In the next section, we will apply these conservation laws to solve problems in fluid mechanics.

### Section: 5.5 Bernoulli's Equation

Bernoulli's equation is a fundamental principle in fluid dynamics that describes the conservation of energy principle for flowing fluids. It is derived from the conservation laws of mass, momentum, and energy, which we discussed in the previous section. Bernoulli's equation is particularly useful in analyzing fluid flow in systems where gravitational potential energy and fluid velocity are changing, such as in pipe flow, open channel flow, and aerodynamics.

#### 5.5.1 Derivation of Bernoulli's Equation

Consider a small fluid element of mass $dm$ moving along a streamline. The work done on the fluid element by the pressure forces and the gravitational force is equal to the change in its kinetic and potential energy. This can be expressed mathematically as:

$$
dW = dK + dU
$$

where $dW$ is the work done on the fluid element, $dK$ is the change in kinetic energy, and $dU$ is the change in potential energy.

The work done by the pressure forces is given by $dW_p = -p dV$, where $p$ is the pressure and $dV$ is the change in volume. The work done by the gravitational force is $dW_g = dm g dz$, where $g$ is the acceleration due to gravity and $dz$ is the change in height. The change in kinetic energy is $dK = \frac{1}{2} dm v dv$, where $v$ is the velocity, and the change in potential energy is $dU = dm g dz$.

Substituting these expressions into the work-energy equation gives:

$$
-p dV + dm g dz = \frac{1}{2} dm v dv + dm g dz
$$

Simplifying and dividing through by $dm$ gives Bernoulli's equation:

$$
-p \frac{dV}{dm} + g dz = \frac{1}{2} v dv + g dz
$$

Finally, recognizing that $\frac{dV}{dm} = \frac{1}{\rho}$, where $\rho$ is the fluid density, we obtain the final form of Bernoulli's equation:

$$
\frac{v^2}{2} + g z + \frac{p}{\rho} = constant
$$

along a streamline.

#### 5.5.2 Applications of Bernoulli's Equation

Bernoulli's equation is widely used in fluid mechanics to analyze fluid flow in various systems. For example, it can be used to calculate the pressure drop along a pipe, the velocity of fluid exiting a nozzle, the lift force on an airplane wing, and the flow rate in an open channel. However, it is important to note that Bernoulli's equation assumes steady, incompressible, inviscid flow along a streamline, and therefore may not accurately describe fluid behavior under conditions where these assumptions are not met.

### Section: 5.6 Flow in Pipes

The flow of fluid in pipes is a fundamental aspect of fluid mechanics and is crucial in various engineering applications such as oil and gas transportation, water supply systems, and HVAC systems. The flow in pipes is governed by several factors, including the fluid's viscosity, the pipe's diameter, and the pressure gradient along the pipe. In this section, we will explore these factors and their influence on the flow characteristics.

#### 5.6a Viscosity and Viscous Flow

Viscosity is a measure of a fluid's resistance to shear or flow. It is a property that plays a significant role in the flow of fluids in pipes. The viscous flow in pipes can be characterized as either laminar or turbulent, depending on the Reynolds number, a dimensionless quantity that describes the flow regime.

The Reynolds number, $Re$, is defined as:

$$
Re = \frac{\rho vD}{\mu}
$$

where $\rho$ is the fluid density, $v$ is the average fluid velocity, $D$ is the pipe diameter, and $\mu$ is the dynamic viscosity of the fluid.

For $Re < 2000$, the flow is considered laminar, and for $Re > 4000$, the flow is considered turbulent. In the laminar flow regime, the fluid flows in parallel layers with no disruption between them. In contrast, in the turbulent flow regime, the fluid particles move in a chaotic manner.

The pressure drop due to viscous effects, $\Delta p$, in a pipe of length $L$ and diameter $D$ can be calculated using the Hagen-Poiseuille equation for laminar flow:

$$
\Delta p = \frac{32 \mu v L}{D^2}
$$

and using the Darcy-Weisbach equation for turbulent flow:

$$
\Delta p = f \frac{L}{D} \frac{1}{2} \rho v^2
$$

where $f$ is the Darcy friction factor, which depends on the Reynolds number and the relative roughness of the pipe.

In the next section, we will discuss the concept of pipe friction and how it affects the flow in pipes.

#### 5.6b Drag and Lift

Drag and lift are two fundamental forces that act on a fluid flowing in a pipe. These forces are responsible for the energy losses that occur during fluid flow and are crucial in determining the efficiency of fluid transportation systems.

##### Drag

Drag is the force that opposes the motion of the fluid. In the context of fluid flow in pipes, it is primarily caused by the friction between the fluid and the pipe walls. This frictional force is a result of the viscosity of the fluid and the roughness of the pipe surface.

The drag force, $F_d$, can be calculated using the following equation:

$$
F_d = \frac{1}{2} C_d \rho v^2 A
$$

where $C_d$ is the drag coefficient, $\rho$ is the fluid density, $v$ is the fluid velocity, and $A$ is the cross-sectional area of the pipe.

The drag coefficient is a dimensionless quantity that depends on the Reynolds number and the relative roughness of the pipe. It can be determined experimentally or using empirical correlations.

##### Lift

Lift is the force that acts perpendicular to the direction of fluid flow. In the context of fluid flow in pipes, lift is typically negligible as the flow is primarily in the axial direction. However, in situations where there are bends or turns in the pipe, lift forces can become significant and can cause additional pressure losses.

The lift force, $F_L$, can be calculated using the following equation:

$$
F_L = \frac{1}{2} C_L \rho v^2 A
$$

where $C_L$ is the lift coefficient, $\rho$ is the fluid density, $v$ is the fluid velocity, and $A$ is the cross-sectional area of the pipe.

Like the drag coefficient, the lift coefficient is a dimensionless quantity that depends on the Reynolds number and the geometry of the pipe. It can also be determined experimentally or using empirical correlations.

In the next section, we will discuss the concept of energy losses in pipe flow and how they can be minimized to improve the efficiency of fluid transportation systems.

#### 5.6c Compressible Flow

Compressible flow refers to the flow of fluids that are susceptible to changes in density. In contrast to incompressible flow, where the density of the fluid is assumed to be constant, compressible flow takes into account the variations in fluid density that can occur due to changes in pressure and temperature. This is particularly relevant for gases and high-speed flows where these changes can be significant.

##### Compressibility Factor

The compressibility factor, often denoted as $Z$, is a dimensionless quantity that describes the deviation of a real gas from ideal gas behavior. It is defined as the ratio of the actual volume of a gas to the volume predicted by the ideal gas law at the same temperature and pressure. Mathematically, it can be expressed as:

$$
Z = \frac{PV}{nRT}
$$

where $P$ is the pressure, $V$ is the volume, $n$ is the number of moles, $R$ is the universal gas constant, and $T$ is the temperature. For an ideal gas, $Z$ equals 1. Deviations from this value indicate the degree of non-ideality or compressibility of the gas.

##### Compressible Flow in Pipes

In the context of fluid flow in pipes, compressible flow can lead to significant changes in fluid velocity, pressure, and density along the length of the pipe. These changes can be described by the conservation of mass and energy principles, leading to the continuity and energy equations.

The continuity equation for compressible flow is given by:

$$
\rho AV = \text{constant}
$$

where $\rho$ is the fluid density, $A$ is the cross-sectional area of the pipe, and $V$ is the fluid velocity. This equation states that the mass flow rate is constant along the pipe.

The energy equation for compressible flow, also known as the Bernoulli's equation for compressible flow, can be derived from the first law of thermodynamics and is given by:

$$
h + \frac{V^2}{2} + gz = \text{constant}
$$

where $h$ is the specific enthalpy of the fluid, $V$ is the fluid velocity, $g$ is the acceleration due to gravity, and $z$ is the height above a reference plane. This equation states that the total energy per unit mass is constant along a streamline.

In the next section, we will discuss the concept of shock waves, a phenomenon unique to compressible flow, and how they can be predicted and mitigated in engineering applications.

#### 5.6d Turbulent Flow

Turbulent flow is a type of fluid (gas or liquid) flow in which the fluid undergoes irregular fluctuations, or mixing. In contrast to laminar flow, which occurs when a fluid flows in parallel layers with no disruption between them, turbulent flow is characterized by chaotic, stochastic property changes. This includes low momentum diffusion, high momentum convection, and rapid variation of pressure and velocity in space and time.

##### Reynolds Number

The transition from laminar to turbulent flow depends on the Reynolds number, a dimensionless quantity used to predict the onset of turbulence. It is defined as the ratio of inertial forces to viscous forces and can be expressed as:

$$
Re = \frac{\rho VD}{\mu}
$$

where $\rho$ is the fluid density, $V$ is the fluid velocity, $D$ is the characteristic linear dimension (typically the hydraulic diameter for a pipe), and $\mu$ is the dynamic viscosity of the fluid. For pipe flow, a Reynolds number less than 2000 typically indicates laminar flow, while a Reynolds number greater than 4000 indicates turbulent flow.

##### Turbulent Flow in Pipes

In the context of fluid flow in pipes, turbulent flow can lead to significant energy losses due to friction. The friction factor, often denoted as $f$, is a dimensionless quantity that describes the resistance to flow. For turbulent flow in smooth pipes, the friction factor can be estimated using the Blasius equation:

$$
f = 0.316 Re^{-0.25}
$$

The energy equation for turbulent flow can be derived from the first law of thermodynamics and is given by:

$$
h + \frac{V^2}{2} + gz + f \frac{L}{D} \frac{V^2}{2} = \text{constant}
$$

where $h$ is the specific enthalpy of the fluid, $V$ is the fluid velocity, $g$ is the acceleration due to gravity, $z$ is the height above a reference plane, $f$ is the friction factor, $L$ is the length of the pipe, and $D$ is the diameter of the pipe. This equation states that the sum of the fluid's enthalpy, kinetic energy, potential energy, and energy loss due to friction is constant along the pipe.

Understanding the nature of turbulent flow and its effects on energy loss is crucial in the design and operation of fluid transport systems, such as pipelines, pumps, and valves.

#### 5.6e Boundary Layer Theory

The boundary layer theory is a fundamental concept in fluid mechanics that describes the behavior of fluid flow near the boundary of a solid object. This theory is particularly important in understanding the flow in pipes, as it helps to explain the frictional losses and heat transfer that occur in these systems.

##### Boundary Layer Formation

The boundary layer forms when a fluid flows over a solid surface. At the surface of the solid, the fluid velocity is zero due to the no-slip condition. However, as we move away from the surface, the fluid velocity increases until it reaches the free stream velocity. This region, where the fluid velocity changes from zero at the wall to the free stream velocity, is known as the boundary layer.

##### Blasius Boundary Layer

The Blasius boundary layer is a solution to the boundary layer equations for steady, two-dimensional, incompressible flow over a flat plate. The Blasius solution is given by:

$$
\frac{du}{dy} = \frac{U}{\sqrt{Re_x}} f'(\eta)
$$

where $u$ is the fluid velocity, $y$ is the distance from the wall, $U$ is the free stream velocity, $Re_x$ is the Reynolds number based on the distance from the leading edge of the plate, $f'(\eta)$ is the derivative of the Blasius function, and $\eta$ is a similarity variable defined as:

$$
\eta = y \sqrt{\frac{U}{\nu x}}
$$

where $\nu$ is the kinematic viscosity of the fluid and $x$ is the distance from the leading edge of the plate.

##### Compressible Blasius Boundary Layer

In the case of compressible flow, the Blasius boundary layer equations become more complex due to the variation of fluid properties such as density, viscosity, and thermal conductivity. The equations for conservation of mass, momentum, and energy in the compressible Blasius boundary layer are given by:

$$
\frac{\partial (\rho u)}{\partial x} + \frac{\partial (\rho v)}{\partial y} = 0,
$$
$$
\rho \left(u \frac{\partial u}{\partial x} + v \frac{\partial u}{\partial y} \right) = \frac{\partial }{\partial y} \left(\mu\frac{\partial u}{\partial y}\right),
$$
$$
\rho \left(u \frac{\partial h}{\partial x} + v \frac{\partial h}{\partial y} \right) = \frac{\partial }{\partial y} \left(\frac{\mu}{Pr} \frac{\partial h}{\partial y} \right) + \mu \left( \frac{\partial u}{\partial y}\right)^2
$$

where $\rho$ is the fluid density, $u$ and $v$ are the fluid velocities in the $x$ and $y$ directions, respectively, $\mu$ is the dynamic viscosity of the fluid, $h$ is the specific enthalpy of the fluid, and $Pr$ is the Prandtl number.

##### Howarth Transformation

The Howarth-Dorodnitsyn transformation is a self-similar transformation that simplifies the compressible Blasius boundary layer equations. The transformation is given by:

$$
\eta = \sqrt{\frac{U}{2\nu_\infty x}} \int_0^y \frac{\rho}{\rho_\infty} dy, \quad f(\eta) = \frac{\psi}{\sqrt{2\nu_\infty U x}}, \quad \tilde h(\eta) = \frac{h}{h_\infty}, \quad \tilde h_w = \frac{h_w}{h_\infty}, \quad \tilde \rho = \frac{\rho}{\rho_\infty},
$$

where $\eta$ is the similarity variable, $f(\eta)$ is the stream function, $\tilde h(\eta)$ is the dimensionless enthalpy, $\tilde h_w$ is the dimensionless wall enthalpy, and $\tilde \rho$ is the dimensionless density.

In the next section, we will discuss the concept of boundary layer separation and its effects on fluid flow in pipes.

### Conclusion

In this chapter, we have delved into the fascinating world of fluid mechanics, a fundamental discipline in unified engineering. We have explored the basic principles that govern the behavior of fluids, both at rest and in motion. We have also examined the key equations and laws that form the foundation of fluid mechanics, such as the Bernoulli's equation and the Navier-Stokes equations. 

We have seen how these principles and equations can be applied to solve real-world problems in various fields of engineering, from designing efficient hydraulic systems to predicting the flow of air over an aircraft wing. We have also discussed the importance of dimensional analysis and similarity in simplifying and solving complex fluid mechanics problems.

In conclusion, fluid mechanics is a critical component of unified engineering, providing the tools and techniques needed to analyze and design systems involving fluids. As we move forward in our study of unified engineering, we will continue to build upon these foundational concepts, applying them to more complex and diverse engineering challenges.

### Exercises

#### Exercise 1
Derive the Bernoulli's equation from the first principles of fluid mechanics. Assume an incompressible, inviscid fluid along a streamline.

#### Exercise 2
The Navier-Stokes equations are a set of nonlinear partial differential equations that describe the motion of viscous fluid substances. Derive the Navier-Stokes equations for a Newtonian fluid.

#### Exercise 3
Using the principles of dimensional analysis, derive the Buckingham's Pi theorem and explain its significance in fluid mechanics.

#### Exercise 4
Consider a fluid flowing over a flat plate with a constant velocity. Using the boundary layer theory, derive the Blasius solution for the velocity profile of the fluid.

#### Exercise 5
Design a simple hydraulic system for a given application. Use the principles and equations of fluid mechanics discussed in this chapter to analyze the performance of the system.

## Chapter: Chapter 6: Circuits and Electronics

### Introduction

Welcome to Chapter 6: Circuits and Electronics. This chapter is designed to provide a comprehensive overview of the fundamental principles and concepts that underpin the field of circuits and electronics. As we delve into this fascinating subject, we will explore the basic components of electronic circuits, including resistors, capacitors, and inductors, and understand how they interact within a circuit.

We will also discuss the laws and principles that govern the behavior of these circuits, such as Ohm's Law and Kirchhoff's Laws. These laws, expressed in mathematical terms, will be presented in the popular TeX and LaTeX style syntax, for example, `$V = IR$` for Ohm's Law, where `$V$` is voltage, `$I$` is current, and `$R$` is resistance.

In addition, we will explore the world of semiconductor devices, including diodes and transistors, and their role in modern electronics. We will also delve into the principles of analog and digital electronics, and how these two domains interact in the design and operation of modern electronic devices.

This chapter will also introduce you to the concept of electronic circuit analysis and design, providing you with the tools and techniques to analyze and design your own circuits. We will discuss various methods of circuit analysis, such as nodal analysis, mesh analysis, and Thevenin and Norton equivalents.

By the end of this chapter, you should have a solid understanding of the basic principles of circuits and electronics, and be well-equipped to apply these principles in practical situations. Whether you're an aspiring engineer, a seasoned professional looking to refresh your knowledge, or simply a curious reader, this chapter aims to provide a comprehensive and accessible guide to the world of circuits and electronics.

### Section: 6.1 Circuit Elements

In this section, we will delve into the fundamental building blocks of electronic circuits, known as circuit elements. These elements are the basic components that make up an electronic circuit and are responsible for the behavior and characteristics of the circuit. 

#### 6.1.1 Resistors

Resistors are one of the most basic and commonly used circuit elements. They are used to limit the flow of electric current in a circuit. The resistance of a resistor is measured in ohms ($\Omega$), and its behavior is governed by Ohm's Law, which states that the voltage across a resistor is directly proportional to the current flowing through it. This relationship is expressed as:

$$
V = IR
$$

where `$V$` is the voltage across the resistor, `$I$` is the current flowing through the resistor, and `$R$` is the resistance of the resistor.

#### 6.1.2 Capacitors

Capacitors are circuit elements that store electrical energy in an electric field. They are often used in electronic circuits for a variety of purposes, such as filtering, energy storage, and coupling. The capacitance of a capacitor is measured in farads (F), and the voltage across a capacitor is related to the charge stored in it by the following equation:

$$
Q = CV
$$

where `$Q$` is the charge stored in the capacitor, `$C$` is the capacitance of the capacitor, and `$V$` is the voltage across the capacitor.

#### 6.1.3 Inductors

Inductors are circuit elements that store energy in a magnetic field when electric current flows through them. They are often used in circuits where the control of current flow is important, such as in power supplies and radio frequency circuits. The inductance of an inductor is measured in henries (H), and the voltage across an inductor is related to the rate of change of current through it by the following equation:

$$
V = L \frac{dI}{dt}
$$

where `$V$` is the voltage across the inductor, `$L$` is the inductance of the inductor, and `$\frac{dI}{dt}$` is the rate of change of current through the inductor.

In the following sections, we will explore these circuit elements in more detail, and discuss how they interact within a circuit to produce the desired electrical behavior. We will also introduce other important circuit elements, such as diodes and transistors, and discuss their role in modern electronics.

### Section: 6.2 Ohm's Law

Ohm's Law is a fundamental principle in the field of electrical engineering and electronics. Named after the German physicist Georg Simon Ohm, it describes the relationship between voltage, current, and resistance in an electrical circuit. 

#### 6.2.1 Statement of Ohm's Law

Ohm's Law states that the current flowing through a conductor between two points is directly proportional to the voltage across the two points, and inversely proportional to the resistance between them. This relationship is mathematically expressed as:

$$
I = \frac{V}{R}
$$

where `$I$` is the current in amperes (A), `$V$` is the voltage in volts (V), and `$R$` is the resistance in ohms (Ω).

#### 6.2.2 Applications of Ohm's Law

Ohm's Law is a fundamental tool in the analysis of electrical circuits. It allows us to calculate the current, voltage, or resistance in a circuit if the other two quantities are known. 

For example, if we know the voltage across a resistor and the resistance of the resistor, we can use Ohm's Law to calculate the current flowing through the resistor. Conversely, if we know the current through a resistor and the resistance, we can calculate the voltage across the resistor.

#### 6.2.3 Limitations of Ohm's Law

While Ohm's Law is a powerful tool in circuit analysis, it is important to note that it is an empirical law and has its limitations. It is applicable to conductors under constant physical conditions such as temperature and pressure. 

In real-world applications, many materials and components do not strictly obey Ohm's Law, especially at high frequencies or under high voltage or temperature conditions. For example, semiconductors, which are widely used in modern electronics, have a non-linear voltage-current relationship that cannot be accurately described by Ohm's Law.

In the next section, we will explore Kirchhoff's Laws, another set of fundamental principles in circuit analysis that, together with Ohm's Law, form the basis for understanding and designing electrical and electronic circuits.

### Section: 6.3 Kirchhoff's Laws

Kirchhoff's Laws, named after the German physicist Gustav Kirchhoff, are two fundamental laws in circuit theory that deal with the conservation of charge and energy. These laws are essential for the analysis of complex electrical circuits and are used in conjunction with Ohm's Law.

#### 6.3.1 Kirchhoff's Current Law (KCL)

Kirchhoff's Current Law, also known as Kirchhoff's First Law or the Junction Rule, states that the algebraic sum of currents entering a node (or a junction) in a circuit equals the sum of currents leaving the same node. This law is a direct consequence of the conservation of electric charge. Mathematically, it can be expressed as:

$$
\sum_{k=1}^{n} I_k = 0
$$

where `$I_k$` is the current entering or leaving the node. Currents entering the node are considered positive, and currents leaving the node are considered negative.

#### 6.3.2 Kirchhoff's Voltage Law (KVL)

Kirchhoff's Voltage Law, also known as Kirchhoff's Second Law or the Loop Rule, states that the algebraic sum of the potential differences (voltages) in any closed loop or mesh in a network is always equal to zero. This law is a direct consequence of the conservation of energy. Mathematically, it can be expressed as:

$$
\sum_{k=1}^{n} V_k = 0
$$

where `$V_k$` is the voltage drop or rise around the loop. Voltage rises are considered positive, and voltage drops are considered negative.

#### 6.3.3 Applications of Kirchhoff's Laws

Kirchhoff's Laws are used to solve complex circuits that cannot be simplified by series and parallel combinations. They are also used in the analysis of AC circuits, where the laws apply to the peak, instantaneous, average, and rms values of voltage and current.

For example, in a network with multiple sources and resistors, Kirchhoff's Laws can be used to set up a system of linear equations, which can then be solved to find the unknown currents and voltages.

#### 6.3.4 Limitations of Kirchhoff's Laws

While Kirchhoff's Laws are powerful tools in circuit analysis, they are based on certain assumptions that may not hold in all situations. For instance, they assume that all circuit elements are lumped, meaning that the physical dimensions of the circuit elements are much smaller than the wavelength of the signal. This assumption breaks down at high frequencies where the wavelength of the signal becomes comparable to the size of the circuit elements.

In the next section, we will explore more advanced topics in circuit analysis, including the use of Thevenin's and Norton's theorems.

### Section: 6.4 DC and AC Circuits

Direct Current (DC) and Alternating Current (AC) are the two types of electric current that exist. In this section, we will explore the characteristics, applications, and differences between these two types of circuits.

#### 6.4.1 Direct Current (DC) Circuits

Direct Current (DC) is the unidirectional flow of electric charge. The electric charge in DC circuits flows in one constant direction, distinguishing it from alternating current (AC). DC can be generated by sources such as batteries, fuel cells, and solar cells.

DC circuits are commonly used in low voltage applications such as charging batteries, electronic systems, and DC motors. They are also used in high voltage electric power transmission lines.

In DC circuits, the voltage and current are constant over time, which simplifies the analysis of these circuits. Ohm's Law and Kirchhoff's Laws, as discussed in the previous sections, are used to analyze DC circuits.

#### 6.4.2 Alternating Current (AC) Circuits

Alternating Current (AC) is the type of electric current in which the direction of the flow of electric charge periodically reverses. AC is the form of electric power that is delivered to businesses and residences. The usual waveform of an AC power circuit is a sine wave, as this results in the most efficient transmission of energy.

AC circuits are used in applications such as power distribution, electric motors, and large appliances. The voltage and current in AC circuits can vary with time, and they can also be out of phase with each other depending on the properties of the circuit elements.

The analysis of AC circuits involves the use of complex numbers and phasors, which take into account the magnitude and phase of the voltage and current.

#### 6.4.3 Comparison of DC and AC Circuits

While DC circuits are simpler to analyze and are used in low voltage applications, AC circuits are more efficient for transmitting electricity over long distances. This is because AC voltages can be easily transformed to higher or lower values using transformers, which is not possible with DC voltages.

Furthermore, AC circuits can handle power factor and impedance, which are important in the operation of many electrical devices. However, AC circuits are more complex to analyze due to the varying voltage and current and the potential for phase differences.

In the next sections, we will delve deeper into the analysis of DC and AC circuits, exploring concepts such as impedance, reactance, and resonance.

### Section: 6.5 Transistors

Transistors are fundamental building blocks of modern electronic devices. They are semiconductor devices that can amplify or switch electronic signals and electrical power. Transistors are the basic elements in integrated circuits (ICs), which consist of a large number of transistors, resistors, diodes, and capacitors interconnected by a conducting layer on a silicon wafer.

#### 6.5.1 Types of Transistors

There are two main types of transistors: Bipolar Junction Transistors (BJTs) and Field Effect Transistors (FETs). 

##### 6.5.1.1 Bipolar Junction Transistors (BJTs)

Bipolar Junction Transistors (BJTs) are three-layer, two pn-junction devices. There are two types of BJTs, NPN and PNP, which are distinguished by the types of semiconductor materials used for the three layers and the direction of current flow. 

In an NPN transistor, a thin and lightly doped P-type base is sandwiched between a heavily doped N-type emitter and a moderately doped N-type collector. In a PNP transistor, the types of layers are reversed.

BJTs are current-controlled devices, in which the base current controls the collector current. They are used in amplifiers, oscillators, and switching circuits.

##### 6.5.1.2 Field Effect Transistors (FETs)

Field Effect Transistors (FETs) are unipolar devices, which means that the current is carried by only one type of carrier, either electrons or holes. There are two main types of FETs: Junction Field Effect Transistors (JFETs) and Metal Oxide Semiconductor Field Effect Transistors (MOSFETs).

In a JFET, the current is controlled by a voltage applied to a reverse-biased pn junction, which modulates the width of a conducting channel. In a MOSFET, the current is controlled by a voltage applied to a metal-oxide-insulator structure, which induces a conducting channel in the underlying semiconductor material.

FETs are voltage-controlled devices, in which the gate voltage controls the drain current. They are used in input amplifiers, oscillators, and digital circuits.

#### 6.5.2 Transistor Operation

The operation of a transistor involves the movement of charge carriers through its semiconductor structure. In a BJT, the emitter-base junction is forward-biased, which allows charge carriers to diffuse from the emitter into the base. The base-collector junction is reverse-biased, which causes the charge carriers to be swept into the collector. The ratio of the collector current to the base current is called the current gain, which is a key parameter of a BJT.

In a FET, the gate voltage induces a conducting channel between the source and the drain. The conductivity of the channel is controlled by the gate voltage, which modulates the drain current. The ratio of the drain current to the gate voltage is called the transconductance, which is a key parameter of a FET.

#### 6.5.3 Transistor Applications

Transistors are used in a wide range of applications. In digital circuits, transistors are used as switches, where a '0' state corresponds to a cutoff transistor and a '1' state corresponds to a saturated transistor. In analog circuits, transistors are used as amplifiers, where the output signal is a scaled version of the input signal.

Transistors are also used in power applications, where they can switch and regulate large amounts of electrical power. In addition, transistors are used in radio frequency applications, where they can generate and amplify high-frequency signals.

In the context of microprocessors, transistors are the fundamental components that enable the complex operations of computing. The evolution of microprocessor technology, as seen in the progression of Apple's silicon, has been largely driven by advances in transistor technology, allowing for increased performance and efficiency.

### Section: 6.6 Amplifiers

Amplifiers are electronic devices that increase the power of a signal. They do this by taking energy from a power supply and controlling the output to match the input signal shape but with a larger amplitude. This process, known as amplification, is fundamental to modern electronics.

#### 6.6.1 Types of Amplifiers

There are several types of amplifiers, each with its unique characteristics and applications. The most common types include operational amplifiers, transistor amplifiers, and differential amplifiers.

##### 6.6.1.1 Operational Amplifiers

Operational amplifiers, often referred to as op-amps, are high-gain electronic voltage amplifiers with a differential input and usually a single-ended output. They are designed to amplify the voltage difference between two input terminal points.

##### 6.6.1.2 Transistor Amplifiers

Transistor amplifiers use a transistor to amplify the input signal. The transistor controls the output current, and by doing so, it increases the power of the signal. Transistor amplifiers are commonly used in applications such as audio amplification and signal processing.

##### 6.6.1.3 Differential Amplifiers

Differential amplifiers amplify the difference between two voltages making this type of amplifier particularly useful in a variety of measurement and test equipment.

### Subsection: 6.6a Filters and Signals

Filters are a significant component in the field of electronics and signal processing. They allow a signal to pass through while blocking others. For instance, audio equalizers are a type of filter that amplifies certain frequencies while attenuating others to modify the sound quality.

#### 6.6a.1 Types of Filters

There are several types of filters, including low-pass, high-pass, band-pass, and band-stop filters.

##### 6.6a.1.1 Low-Pass Filters

Low-pass filters allow signals with a frequency lower than a certain cutoff frequency to pass through and attenuate frequencies higher than the cutoff frequency.

##### 6.6a.1.2 High-Pass Filters

High-pass filters do the opposite of low-pass filters. They allow signals with a frequency higher than a certain cutoff frequency to pass through and attenuate frequencies lower than the cutoff frequency.

##### 6.6a.1.3 Band-Pass Filters

Band-pass filters allow signals within a certain range of frequencies to pass through while attenuating frequencies outside the range.

##### 6.6a.1.4 Band-Stop Filters

Band-stop filters, also known as notch filters, allow most frequencies to pass through but attenuate those in a specific range to very low levels.

In the next section, we will delve deeper into the design and operation of these filters, and how they are used in conjunction with amplifiers in various applications.

### Section: 6.6b Diodes and Rectifiers

Diodes and rectifiers are fundamental components in the field of electronics and circuit design. They play a crucial role in various applications, including power conversion, signal modulation, and voltage regulation.

#### 6.6b.1 Diodes

A diode is a two-terminal electronic component that conducts current primarily in one direction. It has low resistance in one direction, and high resistance in the other. Diodes are often referred to as "D" on PCBs, and sometimes the abbreviation "CR" for "crystal rectifier" is used.

##### 6.6b.1.1 PIN Diodes

PIN diodes are a type of photodiode that are structured to create an intrinsic region between a p-type and an n-type region. This intrinsic region is the basis for the diode's properties and name. Examples of general-purpose PIN diodes include the SFH203 and BPW34, which are housed in 5 mm clear plastic cases and have bandwidths over 100 MHz.

##### 6.6b.1.2 Step Recovery Diodes

Step recovery diodes (SRDs) are a type of diode with the ability to generate extremely short pulses. They are used in pulse generators and microwave frequency multipliers. The theory of non-equilibrium charge transport in semiconductor diodes, including SRDs, is extensively analyzed in various literature.

#### 6.6b.2 Rectifiers

A rectifier is an electrical device that converts alternating current (AC), which periodically reverses direction, to direct current (DC), which flows in only one direction. The process is known as rectification.

##### 6.6b.2.1 Half-Wave Rectifiers

A half-wave rectifier allows only one half (either positive or negative) of an AC waveform to pass through to the load. While simple and cheap to implement, half-wave rectification results in a lot of power being wasted.

##### 6.6b.2.2 Full-Wave Rectifiers

Full-wave rectifiers improve on the efficiency of half-wave rectifiers by utilizing both the positive and negative halves of the AC waveform. This results in a smoother DC output, making full-wave rectifiers more commonly used in most power supplies.

In the next section, we will delve into the world of transistors, exploring their types, characteristics, and applications in circuit design and electronics.

